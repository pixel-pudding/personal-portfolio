Design a unique, premium personal portfolio website for Aditi, a Computer Science student and aspiring Software Engineer.

IMPORTANT DESIGN DIRECTION:

Use the uploaded reference images and the referenced portfolio website only as inspiration for the level of creativity, personality, and interactivity.

DO NOT copy their layouts, visual designs, colors, illustrations, 3D elements, or structure.

The website should feel like:

"A digital engineering notebook brought to life."

It should combine:
- graph paper / engineering notebook aesthetics
- modern developer interfaces
- editorial web design
- soft pastel gradients
- subtle glow effects
- sophisticated micro-interactions
- Framer Motion-style animations

The result should feel personal, memorable, technical and artistic without becoming overly complicated.

LIGHT MODE ONLY.

--------------------------------------------------
1. OVERALL VISUAL STYLE
--------------------------------------------------

Use a warm off-white paper background:

#FAF9F5

The entire website should have a very subtle engineering graph-paper grid.

The grid should be:
- extremely thin
- low opacity
- evenly spaced
- subtle enough that text remains highly readable

The background should resemble premium engineering graph paper rather than a spreadsheet.

Use a soft color palette:

Dark charcoal:
#25252B

Lavender:
#C8C6E5

Periwinkle:
#A8B7D8

Muted mint:
#B8CCC5

Soft dusty pink:
#E7D4DF

Warm beige:
#E8E2D5

Use these colors primarily through subtle gradients, highlights and accents.

Avoid:
- dark mode
- cyberpunk aesthetics
- harsh neon
- excessive glassmorphism
- excessive 3D
- excessive shadows
- generic portfolio templates

The overall feeling should be:

clean + intelligent + creative + soft + futuristic.

--------------------------------------------------
2. NAVIGATION
--------------------------------------------------

Create a minimal floating navigation bar.

Left:

aditi.

Right:

Home
About
Projects
Skills
Journey
Contact

Also include a tiny status indicator:

● available for internships

The navbar should look like a small UI element floating over graph paper.

Use:
- rounded corners
- thin border
- very subtle shadow
- slight translucent paper effect

On hover:
- animated underline
- slight text movement
- subtle glow

--------------------------------------------------
3. HERO — MAKE THIS THE MOST IMPACTFUL SECTION
--------------------------------------------------

The hero should NOT look like a standard portfolio hero.

Do NOT use:

"Hi, I'm Aditi"

as the main headline.

Instead create a strong editorial hero:

01 / INTRODUCTION

BUILDING THINGS
WITH CODE +
curiosity.

Use a modern sans-serif for:

BUILDING THINGS
WITH CODE +

Use an elegant italic serif / editorial font for:

curiosity.

Make "curiosity" slightly larger and give it a very subtle lavender-to-blue gradient.

Below the heading:

Computer Science student building full-stack applications,
AI-powered systems and things that make me curious.

Add two buttons:

VIEW MY WORK →
LET'S CONNECT →

The hero should have an asymmetric layout.

--------------------------------------------------
4. HERO — INTERACTIVE DEVELOPER NOTEBOOK
--------------------------------------------------

On the right side of the hero, create a visually interesting floating composition.

Instead of a photograph, create a small interactive "developer workspace".

Include several overlapping elements:

A. TERMINAL WINDOW

Show:

$ whoami
> aditi

$ focus
> software engineering

$ stack
> C++ / Python / React / AI

$ status
> building...

Add a blinking cursor.

Give the terminal a subtle lavender/blue glow.

B. SYSTEM STATUS CARD

SYSTEM STATUS

● ONLINE

BUILDING
LEARNING
SHIPPING

C. SMALL CODE CARD

Show a short aesthetically formatted code fragment:

const ideas = build();
const problems = solve();
const future = ship(ideas);

D. SMALL NOTEBOOK NOTE

A small paper-like handwritten note:

"make it useful.
make it beautiful."

E. TECHNICAL ANNOTATIONS

Add tiny labels around the composition:

SYSTEM_01
BUILD_002
CURRENTLY
2026
ONLINE

These should look like handwritten engineering annotations.

Allow the cards to overlap slightly.

The composition should feel like someone placed developer tools, notes and diagrams on an engineering notebook.

--------------------------------------------------
5. HERO BACKGROUND
--------------------------------------------------

Behind the hero, keep the graph-paper grid visible.

Add extremely subtle:

- lavender radial glow
- blue gradient glow
- tiny dots
- thin technical lines
- coordinate markers
- faint code fragments
- small arrows
- tiny numbers

Do not clutter the page.

The empty space should remain important.

--------------------------------------------------
6. HERO MOTION
--------------------------------------------------

Design the interface as if it will be implemented with Framer Motion.

On initial page load:

1. graph-paper grid fades in
2. navbar appears
3. "01 / INTRODUCTION" fades in
4. headline reveals line by line
5. "curiosity" softly transitions from blur to focus
6. description fades in
7. buttons slide upward
8. terminal card appears
9. floating notebook elements appear with staggered timing

Use smooth spring-based motion.

Do NOT make elements bounce excessively.

Mouse interaction:

- subtle cursor-following gradient
- terminal moves slightly with cursor
- notebook note moves slightly in another direction
- technical annotations have tiny parallax
- background glow follows the cursor

The movement should be subtle and premium.

--------------------------------------------------
7. SCROLL EXPERIENCE
--------------------------------------------------

Make scrolling feel interactive.

Use Framer Motion-inspired:

- fade-in reveals
- upward slide reveals
- staggered children
- blur-to-focus transitions
- subtle parallax
- animated section numbers

Do not animate every element.

Animation should guide the viewer's attention.

--------------------------------------------------
8. PROJECTS
--------------------------------------------------

Create:

02 / SELECTED WORK

Heading:

things I've built.

Show three main projects:

01 — SKILLSWAP
Peer-to-peer skill exchange platform

02 — VERITY
Barcode scanning and price comparison application

03 — TASKPILOT
AI-powered task intelligence system

Use large, visually distinct project cards.

Do NOT make all cards identical.

Use an editorial asymmetric grid.

Each card should include:

project number
project name
short description
technology
GitHub
Live Demo
arrow

Use subtle pastel gradients inside project cards.

Each project can have its own visual identity:

SkillSwap:
lavender / blue

Verity:
blue / mint

TaskPilot:
lavender / dusty pink

On hover:

- card lifts slightly
- gradient expands
- project preview scales slightly
- arrow moves 4px
- border becomes brighter
- internal elements subtly shift

--------------------------------------------------
9. SKILLS — LARGE SQUARE MODULES
--------------------------------------------------

Create a major visual section:

03 / TOOLBOX

Heading:

things I build with.

IMPORTANT:

DO NOT use a wall of small technology pills.

DO NOT make the skills section look like a normal resume.

Instead create LARGE SQUARE / RECTANGULAR MODULES.

The skill section should visually resemble a collection of large engineering notebook tiles.

Create six large modules:

01
LANGUAGES

C++
Python
Java
JavaScript / TypeScript


02
FRONTEND

React
Vite
TypeScript
Tailwind CSS


03
BACKEND

Node.js
Express.js
FastAPI


04
AI / DATA

Python
NumPy
Pandas
Scikit-learn
NLP


05
DATABASES

MongoDB
PostgreSQL
MySQL


06
TOOLS

Git
GitHub
Docker
Figma

Each module should be large and visually important.

Use approximately 2–3 columns depending on screen width.

Give each module:
- large category title
- small index number
- technology list
- subtle decorative technical diagram
- tiny arrow in the corner

Use slightly different muted pastel gradients for each module.

Example:

LANGUAGES → lavender
FRONTEND → periwinkle
BACKEND → mint
AI / DATA → lavender/pink
DATABASES → warm beige
TOOLS → blue/mint

On hover:

- card lifts 5–8px
- subtle 1-degree rotation
- gradient glow appears
- internal content shifts
- arrow moves
- decorative diagram animates

The skill section should be one of the strongest visual sections on the page.

--------------------------------------------------
10. ABOUT
--------------------------------------------------

Create:

04 / ABOUT

Make the About section feel like an engineer's personal notebook.

Large editorial text:

I like understanding
how things work —
and then building them.

Include a concise personal introduction.

Alongside it, create small information cards:

EDUCATION
B.Tech Computer Science

FOCUS
Software Engineering
AI
Full Stack

INTERESTS
Building
Learning
Experimenting

CURRENTLY
Improving DSA
Building projects
Exploring AI systems

Add subtle notebook-style annotations and technical diagrams.

--------------------------------------------------
11. JOURNEY
--------------------------------------------------

Create:

05 / JOURNEY

Instead of a corporate resume timeline, create a hand-drawn engineering-style timeline.

Use:

2024
LEARNING

2025
BUILDING

2026
SHIPPING

NEXT
?

Connect them using a thin technical line.

Add small glowing nodes.

When scrolling into the section, the line should progressively draw itself.

--------------------------------------------------
12. CONTACT
--------------------------------------------------

Create a visually memorable final section.

Large heading:

LET'S BUILD
SOMETHING
INTERESTING.

Use a large editorial type treatment.

Place a subtle lavender/blue gradient glow behind the text.

Add:

GitHub
LinkedIn
Email

Create a small terminal:

$ echo "hello"

with a blinking cursor.

Include:

open to internships + collaborations

--------------------------------------------------
13. FOOTER
--------------------------------------------------

Minimal footer.

aditi.

Designed + built with curiosity.

C++ · React · Python · AI

Add a tiny:

SYSTEM_STATUS: ONLINE ●

--------------------------------------------------
14. MICRO-INTERACTIONS
--------------------------------------------------

Design all components as if they will later be implemented using Framer Motion.

Use:

- scroll-triggered reveals
- staggered animations
- hover lift
- subtle card tilt
- cursor-following glow
- animated gradients
- parallax
- magnetic buttons
- animated arrows
- animated underlines
- blinking terminal cursor
- animated technical lines
- subtle text reveals
- blur-to-focus transitions
- floating notebook elements

Keep animations smooth, elegant and restrained.

The site should feel alive without feeling like a motion-design demo.

--------------------------------------------------
15. RESPONSIVE DESIGN
--------------------------------------------------

Design desktop first but make the system responsive.

On mobile:

- maintain the graph-paper background
- stack hero elements
- preserve strong typography
- convert skill grid into one-column or two-column modules
- maintain generous spacing
- keep interactions subtle
- simplify decorative elements where necessary

--------------------------------------------------
16. FINAL ART DIRECTION
--------------------------------------------------

The final website should NOT feel like:

"another developer portfolio."

It should feel like:

"an interactive engineering notebook belonging to a young software engineer."

The visual balance should be approximately:

80% clean UI
15% personality
5% visual magic

The website should be:

unique
light
aesthetic
technical
editorial
interactive
professional
youthful

Use the graph-paper grid as the visual thread connecting the entire website.

Use gradients and glow as accents rather than overwhelming the interface.

The hero should immediately communicate personality.

The skills section should be visually memorable through large square modules.

The interaction quality should feel inspired by modern Framer websites, but the visual identity must remain completely original.