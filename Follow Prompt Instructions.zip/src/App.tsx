import {
  useState, useEffect, useRef,
  type CSSProperties, type PointerEvent,
} from 'react'

/* ────────────────────────────────────────────────────────────────────
   PALETTE
──────────────────────────────────────────────────────────────────── */
const P = {
  coffee:      '#4B2615',
  berkeley:    '#7F5E3C',
  mountain:    '#867679',
  mojave:      '#B9A583',
  almond:      '#D8C8B1',
  sage:        '#9EBD9B',
  muted_sage:  '#ACBDB7',
  deep_green:  '#4E635E',
  charcoal:    '#676D6B',
  pale_butter: '#ECE9BE',
  dusty_rose:  '#E8D1DC',
  dusty_pink:  '#D6B1BB',
  blue_gray:   '#9CABC8',
  pale_blue:   '#CFDBE7',
  cream:       '#F5F0E7',
  paper:       '#F7F3EA',
  ink:         '#2A2318',
  muted:       '#867679',
  rosewood:    '#8F5960',
}

/* ────────────────────────────────────────────────────────────────────
   HOOKS
──────────────────────────────────────────────────────────────────── */
function useReveal() {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('visible'); obs.disconnect() } },
      { threshold: 0.12 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return ref
}

function useJourneyLine() {
  const ref = useRef<SVGPathElement>(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('drawn'); obs.disconnect() } },
      { threshold: 0.25 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return ref
}

/* ────────────────────────────────────────────────────────────────────
   ASTERISK CURSOR — pure DOM, zero React state, GPU-friendly
──────────────────────────────────────────────────────────────────── */
function lerp(a: string, b: string, t: number): string {
  const h = (s: string) => [parseInt(s.slice(1,3),16), parseInt(s.slice(3,5),16), parseInt(s.slice(5,7),16)]
  const [ar,ag,ab] = h(a), [br,bg,bb] = h(b)
  return `rgb(${Math.round(ar+(br-ar)*t)},${Math.round(ag+(bg-ag)*t)},${Math.round(ab+(bb-ab)*t)})`
}

function AsteriskCursor() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const starRef   = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const star   = starRef.current
    if (!canvas || !star) return

    const ctx = canvas.getContext('2d')!
    let W = window.innerWidth, H = window.innerHeight
    canvas.width = W; canvas.height = H

    const onResize = () => {
      W = window.innerWidth; H = window.innerHeight
      canvas.width = W; canvas.height = H
    }
    window.addEventListener('resize', onResize)

    // Mouse state — no React, plain refs
    let mx = -300, my = -300
    let lx = -300, ly = -300

    type Pt = { x: number; y: number; age: number }
    const trail: Pt[] = []

    const onMove = (e: MouseEvent) => {
      mx = e.clientX; my = e.clientY

      // Star follows cursor exactly — translate instead of left/top for GPU
      star.style.transform = `translate(calc(${mx}px - 50%), calc(${my}px - 50%))`

      // Deposit trail points proportional to speed
      const dx = mx - lx, dy = my - ly
      const spd = Math.sqrt(dx*dx + dy*dy)
      const pts = Math.min(Math.ceil(spd / 5), 5)
      for (let i = 0; i < pts; i++) trail.push({ x: mx, y: my, age: 0 })
      lx = mx; ly = my
    }
    document.addEventListener('mousemove', onMove)

    function drawStar(x: number, y: number, sz: number, alpha: number, col: string) {
      ctx.save()
      ctx.globalAlpha = alpha
      ctx.strokeStyle = col
      ctx.lineWidth = 1.05
      ctx.lineCap = 'round'
      ctx.translate(x, y)
      for (const a of [0, 45, 90, 135]) {
        ctx.save()
        ctx.rotate(a * Math.PI / 180)
        ctx.beginPath(); ctx.moveTo(0, -sz); ctx.lineTo(0, sz); ctx.stroke()
        ctx.restore()
      }
      ctx.restore()
    }

    let raf = 0
    const tick = () => {
      ctx.clearRect(0, 0, W, H)
      for (let i = trail.length - 1; i >= 0; i--) {
        trail[i].age++
        if (trail[i].age > 26) { trail.splice(i, 1); continue }
        const t = trail[i].age / 26
        const col = t < 0.5
          ? lerp('#8F5960', '#D6B1BB', t * 2)
          : lerp('#D6B1BB', '#E8D1DC', (t - 0.5) * 2)
        drawStar(trail[i].x, trail[i].y, 4.5 * (1 - t * 0.55), (1 - t) * 0.35, col)
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)

    return () => {
      document.removeEventListener('mousemove', onMove)
      window.removeEventListener('resize', onResize)
      cancelAnimationFrame(raf)
    }
  }, [])

  return (
    <>
      <canvas ref={canvasRef} id="cursor-canvas" />
      <div ref={starRef} style={{
        position: 'fixed', top: 0, left: 0,
        pointerEvents: 'none', zIndex: 9999,
        willChange: 'transform',
      }}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none"
          style={{ filter: `drop-shadow(0 0 2.5px ${P.rosewood}55)`, display: 'block' }}>
          <line x1="6.5" y1="1" x2="6.5" y2="12" stroke={P.berkeley} strokeWidth="1.4" strokeLinecap="round"/>
          <line x1="1"   y1="6.5" x2="12" y2="6.5" stroke={P.berkeley} strokeWidth="1.4" strokeLinecap="round"/>
          <line x1="2.5" y1="2.5" x2="10.5" y2="10.5" stroke={P.berkeley} strokeWidth="1.05" strokeLinecap="round"/>
          <line x1="10.5" y1="2.5" x2="2.5" y2="10.5" stroke={P.berkeley} strokeWidth="1.05" strokeLinecap="round"/>
        </svg>
      </div>
    </>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SIGNATURE STAR MOTIF
──────────────────────────────────────────────────────────────────── */
function StarMark({
  size = 9, color = P.mojave, rotate = 0, spin = false,
}: { size?: number; color?: string; rotate?: number; spin?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 10 10"
      style={{ display: 'inline-block', transform: `rotate(${rotate}deg)`, flexShrink: 0 }}
      className={spin ? 'star-spin' : ''}>
      <line x1="5" y1="0.6" x2="5" y2="9.4" stroke={color} strokeWidth="1.1" strokeLinecap="round"/>
      <line x1="0.6" y1="5" x2="9.4" y2="5" stroke={color} strokeWidth="1.1" strokeLinecap="round"/>
      <line x1="1.6" y1="1.6" x2="8.4" y2="8.4" stroke={color} strokeWidth="0.85" strokeLinecap="round"/>
      <line x1="8.4" y1="1.6" x2="1.6" y2="8.4" stroke={color} strokeWidth="0.85" strokeLinecap="round"/>
    </svg>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SECTION LABEL
──────────────────────────────────────────────────────────────────── */
function Label({ idx, text }: { idx: string; text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
      <StarMark size={7} color={P.mojave} rotate={22} />
      <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.12em' }}>
        {idx} / {text}
      </span>
      <div style={{ width: 36, height: 1, background: P.almond }} />
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   TYPING HELLO — "Hi, I'm aditi" with gradient aditi
──────────────────────────────────────────────────────────────────── */
const FULL_TEXT = "Hi, I'm aditi"
const PLAIN_END = 8 // "Hi, I'm " is 8 chars

function TypingHello() {
  const [typed, setTyped]   = useState('')
  const [done, setDone]     = useState(false)

  useEffect(() => {
    let i = 0
    const interval = setInterval(() => {
      i++
      setTyped(FULL_TEXT.slice(0, i))
      if (i >= FULL_TEXT.length) {
        clearInterval(interval)
        setTimeout(() => setDone(true), 600)
      }
    }, 72)
    return () => clearInterval(interval)
  }, [])

  const plain    = typed.slice(0, PLAIN_END)
  const gradient = typed.length > PLAIN_END ? typed.slice(PLAIN_END) : ''

  return (
    <div className="anim-fade delay-200" style={{
      fontFamily: 'DM Sans, sans-serif', fontWeight: 400,
      fontSize: 'clamp(1rem, 2vw, 1.18rem)',
      color: P.muted, marginBottom: 20,
      display: 'flex', alignItems: 'baseline', gap: 0, flexWrap: 'wrap',
    }}>
      <span>{plain}</span>
      {gradient && (
        <span style={{
          fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300,
          fontSize: 'clamp(1.05rem, 2.2vw, 1.26rem)',
          background: `linear-gradient(115deg, ${P.dusty_pink} 0%, ${P.mojave} 48%, ${P.deep_green} 100%)`,
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
          letterSpacing: '-0.01em',
        }}>{gradient}</span>
      )}
      {!done && <span className="type-cursor" />}
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   TECH LOGOS
──────────────────────────────────────────────────────────────────── */
function TechLogo({ name, color }: { name: string; color: string }) {
  const s: CSSProperties = { display: 'block' }
  switch (name) {
    case 'React':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <ellipse cx="30" cy="30" rx="27" ry="10" stroke={color} strokeWidth="1.8"/>
        <ellipse cx="30" cy="30" rx="27" ry="10" stroke={color} strokeWidth="1.8" transform="rotate(60 30 30)"/>
        <ellipse cx="30" cy="30" rx="27" ry="10" stroke={color} strokeWidth="1.8" transform="rotate(120 30 30)"/>
        <circle cx="30" cy="30" r="3.5" fill={color}/>
      </svg>)
    case 'Python':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <path d="M30 8 C22 8 16 13 16 21 L16 26 L44 26 L44 30 L16 30 L16 40 C16 48 22 52 30 52 C38 52 44 47 44 40 L44 34 L16 34 L16 30" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
        <circle cx="23" cy="20" r="2.5" fill={color}/>
        <circle cx="37" cy="40" r="2.5" fill={color}/>
      </svg>)
    case 'TypeScript':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s}>
        <rect x="8" y="8" width="44" height="44" rx="7" fill={color} opacity="0.15"/>
        <text x="30" y="39" textAnchor="middle" fontFamily="JetBrains Mono" fontWeight="700" fontSize="20" fill={color}>TS</text>
      </svg>)
    case 'JavaScript':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s}>
        <rect x="8" y="8" width="44" height="44" rx="7" fill={color} opacity="0.2"/>
        <text x="30" y="39" textAnchor="middle" fontFamily="JetBrains Mono" fontWeight="700" fontSize="20" fill={color}>JS</text>
      </svg>)
    case 'C++':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s}>
        <text x="8" y="37" fontFamily="JetBrains Mono" fontWeight="700" fontSize="19" fill={color}>C++</text>
        <line x1="8" y1="43" x2="40" y2="43" stroke={color} strokeWidth="1.2" opacity="0.35"/>
      </svg>)
    case 'Java':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <path d="M24 14 Q30 8 36 14 L36 36 Q36 44 30 48 Q24 44 24 36 Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
        <path d="M18 52 Q30 47 42 52" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      </svg>)
    case 'Node.js':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <path d="M30 10 L48 20 L48 40 L30 50 L12 40 L12 20 Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
        <path d="M30 22 L30 38" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
        <circle cx="30" cy="30" r="3" fill={color}/>
      </svg>)
    case 'Express':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s}>
        <text x="7" y="33" fontFamily="JetBrains Mono" fontSize="11" fontWeight="500" fill={color} letterSpacing="1">exp</text>
        <path d="M7 40 Q20 36 33 40 Q46 44 53 40" stroke={color} strokeWidth="1.3" fill="none" strokeLinecap="round"/>
      </svg>)
    case 'FastAPI':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <circle cx="30" cy="30" r="20" stroke={color} strokeWidth="1.8"/>
        <path d="M30 14 L24 30 L30 30 L24 46" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>)
    case 'MongoDB':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <path d="M30 8 Q39 20 39 33 Q39 45 30 52 Q21 45 21 33 Q21 20 30 8 Z" stroke={color} strokeWidth="1.8"/>
        <line x1="30" y1="40" x2="30" y2="54" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
      </svg>)
    case 'PostgreSQL':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <ellipse cx="30" cy="18" rx="18" ry="8" stroke={color} strokeWidth="1.8"/>
        <path d="M12 18 L12 38 Q12 50 30 50 Q48 50 48 38 L48 18" stroke={color} strokeWidth="1.8"/>
        <line x1="30" y1="10" x2="30" y2="50" stroke={color} strokeWidth="1.2" opacity="0.35"/>
      </svg>)
    case 'MySQL':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <path d="M12 20 L12 40 Q12 48 30 48" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
        <path d="M48 20 L48 28 Q48 36 36 40" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
        <ellipse cx="30" cy="20" rx="18" ry="7" stroke={color} strokeWidth="1.8"/>
      </svg>)
    case 'Git':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <circle cx="18" cy="18" r="5" stroke={color} strokeWidth="1.8"/>
        <circle cx="42" cy="18" r="5" stroke={color} strokeWidth="1.8"/>
        <circle cx="18" cy="44" r="5" stroke={color} strokeWidth="1.8"/>
        <line x1="18" y1="23" x2="18" y2="39" stroke={color} strokeWidth="1.8"/>
        <path d="M23 18 Q30 18 30 26 L30 44 L37 44" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>)
    case 'Docker':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <rect x="10" y="28" width="40" height="16" rx="4" stroke={color} strokeWidth="1.8"/>
        {[14,22,30,38].map(x => <rect key={x} x={x} y="20" width="6" height="8" rx="1.5" stroke={color} strokeWidth="1.4"/>)}
        {[18,26].map(x => <rect key={x} x={x} y="12" width="6" height="8" rx="1.5" stroke={color} strokeWidth="1.4"/>)}
        <path d="M50 32 Q56 28 54 24 Q52 22 48 24" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
      </svg>)
    case 'Figma':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <rect x="20" y="8" width="20" height="20" rx="10" stroke={color} strokeWidth="1.8"/>
        <rect x="20" y="28" width="20" height="20" rx="10" stroke={color} strokeWidth="1.8"/>
        <rect x="20" y="8" width="10" height="20" stroke={color} strokeWidth="1.8" fill={color} opacity="0.13"/>
        <circle cx="40" cy="28" r="10" stroke={color} strokeWidth="1.8"/>
      </svg>)
    case 'NumPy':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <rect x="10" y="10" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8"/>
        <rect x="33" y="10" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8"/>
        <rect x="10" y="33" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8"/>
        <rect x="33" y="33" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8" fill={color} opacity="0.15"/>
      </svg>)
    case 'Pandas':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <rect x="12" y="10" width="10" height="40" rx="5" stroke={color} strokeWidth="1.8"/>
        <rect x="38" y="10" width="10" height="40" rx="5" stroke={color} strokeWidth="1.8"/>
        <rect x="22" y="22" width="16" height="16" rx="3" stroke={color} strokeWidth="1.5" opacity="0.5"/>
      </svg>)
    case 'Scikit':
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
        <circle cx="30" cy="30" r="18" stroke={color} strokeWidth="1.8"/>
        <path d="M20 30 Q30 18 40 30 Q30 42 20 30 Z" stroke={color} strokeWidth="1.5" fill={color} opacity="0.12"/>
      </svg>)
    default:
      return (<svg viewBox="0 0 60 60" width="34" height="34" style={s}>
        <text x="30" y="36" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="13" fontWeight="500" fill={color}>{name.slice(0,3)}</text>
      </svg>)
  }
}

/* ────────────────────────────────────────────────────────────────────
   NAVBAR
──────────────────────────────────────────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', h)
    return () => window.removeEventListener('scroll', h)
  }, [])
  return (
    <nav className="fixed top-4 left-1/2 z-50 anim-fade delay-200"
      style={{ transform: 'translateX(-50%)', width: 'min(920px, calc(100vw - 2rem))' }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '10px 20px', borderRadius: 14,
        background: scrolled ? 'rgba(247,243,234,0.98)' : 'rgba(247,243,234,0.9)',
        border: `1px solid rgba(135,118,102,${scrolled ? '0.2' : '0.12'})`,
        boxShadow: scrolled ? '0 4px 18px rgba(75,38,21,0.08)' : '0 2px 10px rgba(75,38,21,0.04)',
        backdropFilter: 'blur(6px)', transition: 'all 0.3s ease',
      }}>
        <span style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: '1.1rem', color: P.coffee }}>
          aditi.
        </span>
        <div className="hidden md:flex items-center gap-5">
          {['Home','About','Projects','Skills','Journey','Contact'].map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} className="nav-link"
              style={{ fontSize: '0.82rem', fontWeight: 500, color: P.ink, opacity: 0.62, textDecoration: 'none', transition: 'opacity 0.2s' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = '1' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = '0.62' }}
            >{l}</a>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: P.sage, display: 'inline-block', boxShadow: `0 0 6px ${P.sage}` }} />
          <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.03em' }}>available for internships</span>
        </div>
      </div>
    </nav>
  )
}

/* ────────────────────────────────────────────────────────────────────
   HERO NOTEBOOK — realistic code, no motivational text
──────────────────────────────────────────────────────────────────── */
function NotebookSketch({ tiltX, tiltY }: { tiltX: number; tiltY: number }) {
  return (
    <div style={{
      transform: `perspective(900px) rotateY(${tiltX * 3}deg) rotateX(${-tiltY * 2}deg)`,
      transition: 'transform 0.55s cubic-bezier(0.22,1,0.36,1)',
    }}>
      <div style={{
        background: '#FFFEF8', borderRadius: 10,
        border: '1.5px solid rgba(135,118,102,0.17)',
        padding: '24px 26px 28px', width: 292,
        boxShadow: '4px 8px 32px rgba(75,38,21,0.1), 0 1px 4px rgba(75,38,21,0.05)',
        position: 'relative',
        backgroundImage: 'linear-gradient(rgba(135,118,102,0.048) 1px, transparent 1px)',
        backgroundSize: '100% 26px', backgroundPositionY: '44px',
      }}>
        {/* Margin line */}
        <div style={{ position: 'absolute', left: 44, top: 0, bottom: 0, width: 1, background: 'rgba(214,177,187,0.48)' }} />
        {/* Page tab */}
        <div style={{ position: 'absolute', top: -1, right: 22, width: 38, height: 4, background: P.almond, borderRadius: '0 0 4px 4px' }} />
        {/* Tape */}
        <div style={{ position: 'absolute', top: 5, left: -10, width: 52, height: 11, background: 'rgba(236,233,190,0.6)', borderRadius: 2, transform: 'rotate(-5deg)', boxShadow: 'inset 0 0 4px rgba(0,0,0,0.04)' }} />
        {/* Punched holes */}
        <div style={{ position: 'absolute', left: 14, top: '30%', width: 8, height: 8, borderRadius: '50%', border: '1px solid rgba(135,118,102,0.2)', background: 'rgba(247,243,234,0.8)' }} />
        <div style={{ position: 'absolute', left: 14, top: '62%', width: 8, height: 8, borderRadius: '50%', border: '1px solid rgba(135,118,102,0.2)', background: 'rgba(247,243,234,0.8)' }} />

        <div style={{ paddingLeft: 26, fontFamily: 'JetBrains Mono', fontSize: '0.69rem', lineHeight: 2.05 }}>
          <div style={{ color: P.muted_sage, marginBottom: 2 }}>{'// task pipeline'}</div>
          {[
            { kw: 'const ', name: 'idea',    op: ' = ', val: 'curiosity;' },
            { kw: 'const ', name: 'problem', op: ' = ', val: 'solve(idea);' },
            { kw: 'const ', name: 'result',  op: ' = ', val: 'ship(problem);' },
          ].map(({ kw, name, op, val }) => (
            <div key={name}>
              <span style={{ color: P.deep_green }}>{kw}</span>
              <span style={{ color: P.ink }}>{name}</span>
              <span style={{ color: P.mountain }}>{op}</span>
              <span style={{ color: P.coffee }}>{val}</span>
            </div>
          ))}
          <div style={{ marginTop: 6 }}>
            <div style={{ color: P.muted_sage }}>{'// iterate until it works'}</div>
            <div><span style={{ color: P.deep_green }}>while </span><span style={{ color: P.mountain }}>{'(!done) {'}</span></div>
            <div style={{ paddingLeft: 14 }}>
              <div><span style={{ color: P.ink }}>{'build();'}</span></div>
              <div><span style={{ color: P.ink }}>{'test();'}</span></div>
              <div><span style={{ color: P.ink }}>{'debug();'}</span></div>
            </div>
            <div style={{ color: P.mountain }}>{'}'}</div>
          </div>
          <div style={{ marginTop: 6, color: P.muted_sage }}>{'// TODO: refactor this'}</div>
          <div style={{ marginTop: 4 }}>
            <span style={{ color: P.mojave }}>{'> '}</span>
            <span className="cursor-blink" style={{ color: P.deep_green }}>▌</span>
          </div>
        </div>

        <div style={{ position: 'absolute', bottom: 12, right: 12, display: 'flex', alignItems: 'center', gap: 5 }}>
          <StarMark size={6} color={P.almond} rotate={15} />
          <span style={{ fontFamily: 'Caveat', fontSize: '0.7rem', color: P.almond, border: '1px solid rgba(185,165,131,0.28)', borderRadius: '50%', width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>'26</span>
        </div>
      </div>
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   HERO
──────────────────────────────────────────────────────────────────── */
function Hero() {
  const [cursor, setCursor] = useState({ x: 0.5, y: 0.5 })
  const onPointerMove = (e: PointerEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    setCursor({ x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height })
  }
  const tiltX = cursor.x * 2 - 1
  const tiltY = cursor.y * 2 - 1
  return (
    <section id="home" onPointerMove={onPointerMove}
      className="graph-paper relative min-h-screen flex items-center pt-28 pb-20 overflow-hidden">
      {/* Soft cursor glow */}
      <div style={{
        position: 'absolute', pointerEvents: 'none',
        width: 460, height: 460, borderRadius: '50%',
        background: `radial-gradient(circle, rgba(172,189,183,0.08) 0%, rgba(232,209,220,0.05) 38%, rgba(185,165,131,0.04) 60%, transparent 72%)`,
        left: `calc(${cursor.x * 100}% - 230px)`, top: `calc(${cursor.y * 100}% - 230px)`,
        transition: 'left 0.55s ease, top 0.55s ease', zIndex: 0,
      }} />
      <div className="relative z-10 w-full max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            {/* Typing greeting */}
            <TypingHello />

            <h1 style={{ margin: 0, lineHeight: 0.92 }}>
              <div className="anim-fade-up delay-400" style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,6vw,4.8rem)', color: P.ink, letterSpacing: '-0.03em', lineHeight: 0.92 }}>
                BUILDING THINGS
              </div>
              <div className="anim-fade-up delay-500" style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,6vw,4.8rem)', color: P.ink, letterSpacing: '-0.03em', lineHeight: 0.92 }}>
                WITH CODE +
              </div>
              <div className="anim-blur-in delay-700" style={{
                fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300,
                fontSize: 'clamp(3rem,7vw,5.6rem)', letterSpacing: '-0.02em', lineHeight: 1.1,
                background: `linear-gradient(115deg, ${P.dusty_pink} 0%, ${P.mojave} 48%, ${P.deep_green} 100%)`,
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
              }}>curiosity.</div>
            </h1>

            <p className="anim-fade-up delay-800" style={{ color: P.muted, fontSize: '0.95rem', lineHeight: 1.75, marginTop: 18, maxWidth: 400 }}>
              Computer Science student building full-stack applications,<br />
              AI-powered systems and things that make me curious.
            </p>
            <div className="anim-fade-up delay-1000 flex flex-wrap gap-3 mt-8">
              <a href="#projects" className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: P.coffee, color: '#FDF8F2',
                padding: '11px 22px', borderRadius: 8,
                fontFamily: 'DM Sans, sans-serif', fontWeight: 600, fontSize: '0.78rem', letterSpacing: '0.05em',
                textDecoration: 'none', transition: 'background 0.22s ease',
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = P.deep_green }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = P.coffee }}
              >VIEW MY WORK →</a>
              <a href="#contact" className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: P.cream, color: P.coffee,
                padding: '11px 22px', borderRadius: 8,
                fontFamily: 'DM Sans, sans-serif', fontWeight: 600, fontSize: '0.78rem', letterSpacing: '0.05em',
                textDecoration: 'none', border: `1.5px solid rgba(75,38,21,0.2)`,
                transition: 'background 0.2s, border-color 0.2s',
              }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.background = P.almond; el.style.borderColor = 'rgba(75,38,21,0.38)' }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.background = P.cream; el.style.borderColor = 'rgba(75,38,21,0.2)' }}
              >LET'S CONNECT →</a>
            </div>
          </div>
          <div className="anim-fade-up delay-900 hidden md:flex justify-center items-center">
            <NotebookSketch tiltX={tiltX} tiltY={tiltY} />
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   PROJECT SKETCHES
──────────────────────────────────────────────────────────────────── */
function SkillSwapSketch({ hov }: { hov: boolean }) {
  return (
    <svg viewBox="0 0 160 88" width="160" height="88" fill="none"
      style={{ opacity: hov ? 1 : 0.52, transition: 'opacity 0.3s, transform 0.3s', transform: hov ? 'scale(1.04)' : 'scale(1)' }}>
      <circle cx="28" cy="44" r="15" stroke={P.dusty_pink} strokeWidth="1.4"/>
      <circle cx="132" cy="44" r="15" stroke={P.mojave} strokeWidth="1.4"/>
      <circle cx="80" cy="22" r="11" stroke={P.deep_green} strokeWidth="1.4"/>
      <path d="M43 44 L68 44" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <path d="M92 44 L117 44" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <path d="M43 40 L72 27" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <path d="M88 27 L117 41" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <text x="21" y="48" fontFamily="Caveat" fontSize="8.5" fill={P.dusty_pink}>learn</text>
      <text x="118" y="48" fontFamily="Caveat" fontSize="8.5" fill={P.mojave}>teach</text>
      <text x="68" y="27" fontFamily="Caveat" fontSize="8.5" fill={P.deep_green}>you</text>
      <path d="M70 68 Q80 64 90 68" stroke={P.mountain} strokeWidth="0.9" strokeLinecap="round" strokeDasharray="3 2"/>
      <text x="70" y="79" fontFamily="Caveat" fontSize="7" fill={P.charcoal}>// edge case?</text>
    </svg>
  )
}

function VeritySketch({ hov }: { hov: boolean }) {
  return (
    <svg viewBox="0 0 160 88" width="160" height="88" fill="none"
      style={{ opacity: hov ? 1 : 0.52, transition: 'opacity 0.3s, transform 0.3s', transform: hov ? 'scale(1.04)' : 'scale(1)' }}>
      {[20,24,29,32,37,40,44,48,52,55,59,62].map((x, i) => (
        <rect key={i} x={x} y={18} width={i % 3 === 0 ? 3 : 1.5} height={48} fill={P.deep_green} opacity={0.65}/>
      ))}
      <text x="28" y="78" fontFamily="JetBrains Mono" fontSize="6.5" fill={P.mountain} letterSpacing="2">4901234</text>
      <path d="M88 26 L132 26 L146 44 L132 62 L88 62 Z" stroke={P.sage} strokeWidth="1.4"/>
      <circle cx="94" cy="33" r="3" stroke={P.sage} strokeWidth="1.1"/>
      <text x="102" y="46" fontFamily="Caveat" fontSize="13" fill={P.deep_green}>₹449</text>
      <text x="102" y="57" fontFamily="Caveat" fontSize="8.5" fill={P.mountain}>↓ from ₹699</text>
      <path d="M68 44 L83 44" stroke={P.almond} strokeWidth="1.3" strokeDasharray="3 2"/>
      <path d="M79 41 L85 44 L79 47" fill={P.almond}/>
    </svg>
  )
}

function TaskPilotSketch({ hov }: { hov: boolean }) {
  return (
    <svg viewBox="0 0 160 88" width="160" height="88" fill="none"
      style={{ opacity: hov ? 1 : 0.52, transition: 'opacity 0.3s, transform 0.3s', transform: hov ? 'scale(1.04)' : 'scale(1)' }}>
      <rect x="8"  y="33" width="30" height="22" rx="4" stroke={P.pale_butter} strokeWidth="1.4"/>
      <rect x="64" y="18" width="32" height="18" rx="4" stroke={P.blue_gray}   strokeWidth="1.4"/>
      <rect x="64" y="52" width="32" height="18" rx="4" stroke={P.mojave}      strokeWidth="1.4"/>
      <rect x="120" y="33" width="32" height="22" rx="4" stroke={P.sage}       strokeWidth="1.4"/>
      <path d="M38 40 L59 27" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <path d="M38 48 L59 59" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <path d="M96 30 L115 42" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <path d="M96 58 L115 48" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <text x="12" y="46" fontFamily="Caveat" fontSize="8"   fill={P.pale_butter}>tasks</text>
      <text x="68" y="29" fontFamily="Caveat" fontSize="7.5" fill={P.blue_gray}>AI sort</text>
      <text x="68" y="64" fontFamily="Caveat" fontSize="7.5" fill={P.mojave}>priority</text>
      <text x="124" y="46" fontFamily="Caveat" fontSize="7.5" fill={P.sage}>done ✓</text>
      {hov && <circle cx="80" cy="44" r="4" fill={P.blue_gray} opacity="0.32"/>}
    </svg>
  )
}

/* ────────────────────────────────────────────────────────────────────
   PROJECTS
──────────────────────────────────────────────────────────────────── */
const PROJECTS = [
  {
    num: '01', name: 'SkillSwap',
    desc: 'Peer-to-peer skill exchange platform connecting learners and experts in real time.',
    tech: ['React', 'Node.js', 'MongoDB', 'Express'],
    cardBg: 'linear-gradient(145deg, #FDF6F8 0%, #F5EAEF 100%)',
    borderColor: 'rgba(214,177,187,0.55)',
    accentColor: P.dusty_pink,
    accentText: P.berkeley,
    Sketch: SkillSwapSketch,
  },
  {
    num: '02', name: 'Verity',
    desc: 'Barcode scanning and real-time price comparison for smarter shopping decisions.',
    tech: ['Python', 'FastAPI', 'React', 'PostgreSQL'],
    cardBg: 'linear-gradient(145deg, #F2F8F4 0%, #E6F2E8 100%)',
    borderColor: 'rgba(158,189,155,0.5)',
    accentColor: P.sage,
    accentText: P.deep_green,
    Sketch: VeritySketch,
  },
  {
    num: '03', name: 'TaskPilot',
    desc: 'AI-powered task intelligence that prioritizes, schedules and learns your workflow.',
    tech: ['Python', 'NLP', 'React', 'TypeScript'],
    cardBg: 'linear-gradient(145deg, #F6F9F0 0%, #EBF0F8 100%)',
    borderColor: 'rgba(156,171,200,0.45)',
    accentColor: P.blue_gray,
    accentText: P.deep_green,
    Sketch: TaskPilotSketch,
  },
]

function ProjectCard({ p }: { p: typeof PROJECTS[0] }) {
  const [hov, setHov] = useState(false)
  const Sketch = p.Sketch
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? p.cardBg : '#FFFEF9',
        border: `1.5px solid ${hov ? p.borderColor : 'rgba(135,118,102,0.1)'}`,
        borderRadius: 14, padding: '26px 22px',
        transform: hov ? 'translateY(-6px)' : 'none',
        boxShadow: hov ? '0 18px 50px rgba(75,38,21,0.08)' : '0 2px 8px rgba(75,38,21,0.03)',
        transition: 'all 0.32s cubic-bezier(0.22,1,0.36,1)',
        display: 'flex', flexDirection: 'column',
        position: 'relative', overflow: 'hidden',
      }}>
      <div style={{ height: 2, borderRadius: 4, marginBottom: 18, background: p.accentColor, width: hov ? '100%' : '26%', transition: 'width 0.4s ease' }} />
      <div style={{ position: 'absolute', top: 18, right: 18, transform: hov ? 'rotate(45deg)' : 'rotate(0deg)', transition: 'transform 0.4s ease' }}>
        <StarMark size={8} color={p.accentColor} rotate={0} />
      </div>
      <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.6rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 8 }}>{p.num} — PROJECT</div>
      <h3 className="pastel-hl" style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '1.3rem', color: P.ink, letterSpacing: '-0.02em', marginBottom: 10 }}>{p.name}</h3>
      <p style={{ color: P.muted, fontSize: '0.84rem', lineHeight: 1.65, marginBottom: 18, flex: 1 }}>{p.desc}</p>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
        <Sketch hov={hov} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
          {p.tech.map(t => (
            <span key={t} style={{ fontSize: '0.64rem', color: p.accentText, padding: '3px 8px', background: `${p.accentColor}18`, borderRadius: 5, fontFamily: 'JetBrains Mono' }}>{t}</span>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 5 }}>
          {['GitHub','Live'].map(l => (
            <a key={l} href="#" style={{ fontSize: '0.64rem', color: P.muted, padding: '3px 8px', border: '1px solid rgba(135,118,102,0.18)', borderRadius: 5, textDecoration: 'none', fontFamily: 'JetBrains Mono', transition: 'color 0.2s, border-color 0.2s' }}
              onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.color = P.ink; el.style.borderColor = 'rgba(135,118,102,0.4)' }}
              onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.color = P.muted; el.style.borderColor = 'rgba(135,118,102,0.18)' }}
            >{l}</a>
          ))}
        </div>
      </div>
    </div>
  )
}

function Projects() {
  const ref = useReveal()
  return (
    <section id="projects" className="graph-paper py-24 px-6 relative">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="02" text="SELECTED WORK" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 44 }}>
            things I've built.
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 18 }}>
          {PROJECTS.map(p => <ProjectCard key={p.num} p={p} />)}
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SKILLS — full palette tile colors
──────────────────────────────────────────────────────────────────── */
const ROW1 = [
  { name: 'React',      cat: 'FRONTEND',  tileBg: 'linear-gradient(135deg,#EEF4FC,#E2EBF8)', logoColor: P.blue_gray,   num: '01' },
  { name: 'Python',     cat: 'LANGUAGE',  tileBg: 'linear-gradient(135deg,#FDFBEA,#F4F0D4)', logoColor: '#5C6E2A',     num: '02' },
  { name: 'Node.js',    cat: 'BACKEND',   tileBg: 'linear-gradient(135deg,#EDF6ED,#DFF0DF)', logoColor: P.deep_green,  num: '03' },
  { name: 'C++',        cat: 'LANGUAGE',  tileBg: 'linear-gradient(135deg,#FAF0F4,#F0E2E9)', logoColor: '#9C5F6E',     num: '04' },
  { name: 'MongoDB',    cat: 'DATABASE',  tileBg: 'linear-gradient(135deg,#EAF2EC,#D8EADB)', logoColor: P.deep_green,  num: '05' },
  { name: 'Git',        cat: 'TOOL',      tileBg: 'linear-gradient(135deg,#F8F2E8,#EDE3D4)', logoColor: P.berkeley,    num: '06' },
  { name: 'Docker',     cat: 'TOOL',      tileBg: 'linear-gradient(135deg,#EDF3FA,#DCEAF6)', logoColor: P.blue_gray,   num: '07' },
  { name: 'TypeScript', cat: 'LANGUAGE',  tileBg: 'linear-gradient(135deg,#EFF3F8,#E0EAF3)', logoColor: '#5A73A8',     num: '08' },
  { name: 'MySQL',      cat: 'DATABASE',  tileBg: 'linear-gradient(135deg,#F4F0EA,#E9E0D5)', logoColor: P.mojave,      num: '09' },
]
const ROW2 = [
  { name: 'JavaScript', cat: 'LANGUAGE',  tileBg: 'linear-gradient(135deg,#FDFADF,#F3EFC6)', logoColor: '#7A6010',     num: '10' },
  { name: 'FastAPI',    cat: 'BACKEND',   tileBg: 'linear-gradient(135deg,#EDF6F3,#DCF0E9)', logoColor: P.muted_sage,  num: '11' },
  { name: 'PostgreSQL', cat: 'DATABASE',  tileBg: 'linear-gradient(135deg,#EEF3FA,#DEE9F5)', logoColor: P.blue_gray,   num: '12' },
  { name: 'Figma',      cat: 'TOOL',      tileBg: 'linear-gradient(135deg,#F7F1E6,#EDE2D0)', logoColor: P.mojave,      num: '13' },
  { name: 'NumPy',      cat: 'AI / DATA', tileBg: 'linear-gradient(135deg,#EEF2FA,#E0EAF5)', logoColor: P.blue_gray,   num: '14' },
  { name: 'Pandas',     cat: 'AI / DATA', tileBg: 'linear-gradient(135deg,#FAF6ED,#EFE8D5)', logoColor: P.berkeley,    num: '15' },
  { name: 'Scikit',     cat: 'AI / DATA', tileBg: 'linear-gradient(135deg,#F4EEF8,#EAE0F0)', logoColor: '#8A6AAC',     num: '16' },
  { name: 'Java',       cat: 'LANGUAGE',  tileBg: 'linear-gradient(135deg,#FBF0EC,#F2E2D9)', logoColor: '#9C6040',     num: '17' },
  { name: 'Express',    cat: 'BACKEND',   tileBg: 'linear-gradient(135deg,#EFF5F0,#E2EDE4)', logoColor: P.charcoal,    num: '18' },
]

function SkillTile({ t }: { t: typeof ROW1[0] }) {
  const [hov, setHov] = useState(false)
  return (
    <div className="skill-tile"
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: 144,
        background: hov ? t.tileBg : '#FFFEF9',
        border: `1.5px solid rgba(135,118,102,${hov ? '0.18' : '0.08'})`,
        borderRadius: 12, padding: '18px 14px 14px', margin: '0 8px',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9,
        boxShadow: hov ? `0 14px 36px rgba(75,38,21,0.09), 0 0 0 1.5px ${t.logoColor}1A` : '0 1px 5px rgba(75,38,21,0.03)',
        position: 'relative', overflow: 'hidden',
      }}>
      <span style={{ position: 'absolute', top: 8, left: 10, fontFamily: 'JetBrains Mono', fontSize: '0.5rem', color: `${t.logoColor}55`, letterSpacing: '0.05em' }}>{t.num}</span>
      <div style={{ position: 'absolute', bottom: -12, right: -12, width: 42, height: 42, borderRadius: '50%', border: `1.5px solid ${t.logoColor}`, opacity: hov ? 0.3 : 0.07, transform: hov ? 'scale(1.3)' : 'scale(1)', transition: 'opacity 0.3s, transform 0.3s' }} />
      <div style={{ transform: hov ? 'scale(1.12)' : 'scale(1)', transition: 'transform 0.3s ease' }}>
        <TechLogo name={t.name} color={t.logoColor} />
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '0.82rem', color: P.ink }}>{t.name}</div>
        <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.5rem', color: P.muted, letterSpacing: '0.1em', marginTop: 3 }}>{t.cat}</div>
      </div>
    </div>
  )
}

function Skills() {
  const ref = useReveal()
  return (
    <section id="skills" className="py-24 overflow-hidden graph-paper-alt">
      <div className="max-w-6xl mx-auto px-6">
        <div ref={ref} className="reveal">
          <Label idx="03" text="TOOLBOX" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 44 }}>
            things I build with.
          </h2>
        </div>
      </div>
      <div style={{ overflow: 'hidden', marginBottom: 14, padding: '6px 0' }}>
        <div className="marquee-fwd" style={{ display: 'flex', alignItems: 'stretch' }}>
          {[...ROW1, ...ROW1].map((t, i) => <SkillTile key={i} t={t} />)}
        </div>
      </div>
      <div style={{ overflow: 'hidden', padding: '6px 0' }}>
        <div className="marquee-rev" style={{ display: 'flex', alignItems: 'stretch' }}>
          {[...ROW2, ...ROW2].map((t, i) => <SkillTile key={i} t={t} />)}
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-6 mt-10 flex items-center gap-3">
        <span style={{ fontFamily: 'Caveat', fontSize: '0.95rem', color: P.mountain }}>// still learning, always curious</span>
        <svg viewBox="0 0 30 10" width="30" height="10" fill="none">
          <path d="M2 5 Q12 2 22 5 Q26 6 28 5" stroke={P.muted_sage} strokeWidth="1.2" strokeLinecap="round"/>
          <path d="M24 2 L28 5 L24 8" stroke={P.muted_sage} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   ABOUT — info cards with distinct gradient colors (not brown)
──────────────────────────────────────────────────────────────────── */
const INFO_CARDS = [
  { label: 'EDUCATION', items: ['B.Tech Computer Science'],             bg: 'linear-gradient(135deg,#FAF5EE,#F2E8DA)', rotate: '-0.4deg', dot: P.mojave },
  { label: 'FOCUS',     items: ['Software Engineering','AI','Full Stack'], bg: 'linear-gradient(135deg,#EEF7EE,#DFF0DF)', rotate: '0.5deg',  dot: P.sage },
  { label: 'INTERESTS', items: ['Building things','Breaking things','Fixing them'], bg: 'linear-gradient(135deg,#FBF0F4,#F4E4EB)', rotate: '-0.3deg', dot: P.dusty_pink },
  { label: 'CURRENTLY', items: ['Sharpening DSA','Shipping projects','Exploring AI'], bg: 'linear-gradient(135deg,#EEF4FA,#DDE9F6)', rotate: '0.4deg',  dot: P.blue_gray },
]

function About() {
  const ref = useReveal()
  return (
    <section id="about" className="graph-paper py-24 px-6 relative">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal"><Label idx="04" text="ABOUT" /></div>
        <div className="grid md:grid-cols-2 gap-16 items-start mt-8">
          <div>
            <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(1.7rem,4vw,2.6rem)', color: P.ink, lineHeight: 1.3, letterSpacing: '-0.02em', marginBottom: 20 }}>
              I like understanding<br />how things work —<br />and then building them.
            </h2>
            <p style={{ color: P.muted, lineHeight: 1.8, fontSize: '0.92rem', maxWidth: 400 }}>
              I'm Aditi, a CS student with a bias for building. Whether it's wiring a full-stack
              app, poking at AI systems, or untangling a tricky algorithm — I go toward problems
              that reward curiosity. I believe software should be both{' '}
              <span style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', color: P.ink }}>useful</span>{' '}
              and{' '}
              <span style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', color: P.ink }}>beautiful</span>.
            </p>
            <div style={{ marginTop: 22, padding: '12px 16px', border: '1px solid rgba(172,189,183,0.4)', borderRadius: 8, background: 'linear-gradient(135deg,#EEF6EE,#E4EFE4)', position: 'relative' }}>
              <div style={{ position: 'absolute', top: -6, left: 14, width: 42, height: 10, background: 'rgba(236,233,190,0.72)', borderRadius: 2, transform: 'rotate(-2deg)' }} />
              <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.68rem', color: P.deep_green }}>{'// B.Tech CS · Year 2 · India'}</div>
              <div style={{ fontFamily: 'Caveat', fontSize: '0.88rem', color: P.mountain, marginTop: 4 }}>open to internships + interesting problems</div>
            </div>
            <div style={{ marginTop: 24 }}>
              <svg viewBox="0 0 200 16" width="200" height="16" fill="none">
                <path d="M4 11 Q40 7 80 10 Q120 13 160 8 Q180 6 196 10" stroke={P.almond} strokeWidth="1.4" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {INFO_CARDS.map((card, i) => (
              <div key={card.label} style={{
                background: card.bg,
                border: '1.5px solid rgba(135,118,102,0.1)',
                borderRadius: 11, padding: '16px 14px',
                transform: `rotate(${card.rotate})`,
                position: 'relative',
              }}>
                <div style={{ position: 'absolute', top: 8, right: 10 }}>
                  <StarMark size={6} color={card.dot} rotate={i * 22} />
                </div>
                <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.58rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 10 }}>{card.label}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                  {card.items.map(item => (
                    <div key={item} style={{ fontSize: '0.8rem', color: P.ink, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ width: 3, height: 3, borderRadius: '50%', background: card.dot, flexShrink: 0 }} />
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   JOURNEY — palette nodes
──────────────────────────────────────────────────────────────────── */
const TIMELINE = [
  { year: '2024', tag: 'LEARNING', desc: 'Foundations: data structures, algorithms, first real projects. A lot of things breaking.', color: P.mojave },
  { year: '2025', tag: 'BUILDING', desc: 'Full-stack apps, AI experiments, open source contributions, learning to ship.',            color: P.muted_sage },
  { year: '2026', tag: 'SHIPPING', desc: 'Real products. SkillSwap, Verity, TaskPilot — and more on the way.',                       color: P.sage },
  { year: 'NEXT', tag: '?',        desc: 'Internships, collaborations, and whatever interesting problem finds me next.',               color: P.dusty_pink },
]

function Journey() {
  const ref = useReveal()
  const lineRef = useJourneyLine()
  return (
    <section id="journey" className="py-24 px-6 graph-paper-alt">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="05" text="JOURNEY" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 52 }}>
            where I've been.
          </h2>
        </div>
        <div style={{ position: 'relative', paddingLeft: 34 }}>
          <svg style={{ position: 'absolute', left: 8, top: 8, width: 6, height: 'calc(100% - 16px)', overflow: 'visible' }}
            viewBox="0 0 6 600" preserveAspectRatio="none">
            <path ref={lineRef} d="M3 0 Q4 80 2 160 Q4 240 3 320 Q2 400 4 480 Q3 540 3 600"
              stroke={P.berkeley} strokeWidth="1.5" fill="none" className="journey-line" strokeLinecap="round"/>
          </svg>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 44 }}>
            {TIMELINE.map((t, i) => (
              <div key={t.year} style={{ position: 'relative', display: 'flex', alignItems: 'flex-start', gap: 22 }}>
                <div style={{ position: 'absolute', left: -34, top: 6, width: 12, height: 12, borderRadius: '50%', background: t.color, border: '2px solid #EDE8DD', boxShadow: `0 0 10px ${t.color}88`, zIndex: 2 }} />
                <div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 7 }}>
                    <span style={{ fontFamily: 'JetBrains Mono', fontWeight: 500, fontSize: '1.05rem', color: P.ink }}>{t.year}</span>
                    <span style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '0.7rem', letterSpacing: '0.09em', color: t.color, padding: '2px 9px', background: `${t.color}22`, borderRadius: 20 }}>{t.tag}</span>
                    {t.year === 'NEXT' && <span style={{ fontFamily: 'Caveat', fontSize: '0.9rem', color: P.mountain }}>↩ TBD</span>}
                    {i === 2 && <span style={{ fontFamily: 'Caveat', fontSize: '0.82rem', color: P.muted }}>this one was fun</span>}
                  </div>
                  <p style={{ color: P.muted, fontSize: '0.88rem', lineHeight: 1.65, maxWidth: 460 }}>{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   CONTACT
──────────────────────────────────────────────────────────────────── */
function Contact() {
  const ref = useReveal()
  return (
    <section id="contact" className="graph-paper py-28 px-6 relative overflow-hidden">
      <div style={{ position: 'absolute', top: '40%', left: '50%', transform: 'translate(-50%,-50%)', width: 520, height: 380, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(172,189,183,0.08) 0%, rgba(232,209,220,0.05) 40%, transparent 68%)', pointerEvents: 'none' }} />
      <div className="max-w-5xl mx-auto relative z-10">
        <div ref={ref} className="reveal text-center">
          <Label idx="06" text="CONTACT" />
          <h2 style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,7vw,5.5rem)', color: P.ink, letterSpacing: '-0.04em', lineHeight: 0.9, marginTop: 14, marginBottom: 20 }}>
            LET'S BUILD<br />
            <span style={{
              fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, letterSpacing: '-0.02em',
              background: `linear-gradient(115deg, ${P.dusty_pink} 0%, ${P.mojave} 50%, ${P.deep_green} 100%)`,
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            }}>SOMETHING</span><br />
            INTERESTING.
          </h2>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 28 }}>
            <span style={{ fontFamily: 'Caveat', fontSize: '1.05rem', color: P.muted_sage }}>open to internships + collaborations</span>
            <svg viewBox="0 0 20 10" width="20" height="10" fill="none">
              <path d="M2 5 Q10 2 17 5" stroke={P.muted_sage} strokeWidth="1.1" strokeLinecap="round"/>
              <path d="M13 2 L17 5 L13 8" stroke={P.muted_sage} strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 52 }}>
            {[
              { label: 'GitHub',   href: 'https://github.com' },
              { label: 'LinkedIn', href: 'https://linkedin.com' },
              { label: 'Email',    href: 'mailto:aditi@example.com' },
            ].map(({ label, href }) => (
              <a key={label} href={href} className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 7,
                padding: '10px 22px', borderRadius: 9,
                border: '1.5px solid rgba(135,118,102,0.18)',
                color: P.ink, fontSize: '0.82rem', fontWeight: 500,
                letterSpacing: '0.04em', textDecoration: 'none',
                background: '#FFFEF9', transition: 'all 0.22s ease',
              }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = P.deep_green; el.style.background = '#EEF6EE' }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'rgba(135,118,102,0.18)'; el.style.background = '#FFFEF9' }}
              >{label} →</a>
            ))}
          </div>
          <div style={{ display: 'inline-block', background: P.ink, color: P.pale_butter, borderRadius: 9, padding: '11px 18px', fontFamily: 'JetBrains Mono', fontSize: '0.7rem' }}>
            {'$ echo "hello"'}
            <span className="cursor-blink" style={{ color: P.sage, marginLeft: 4 }}>▌</span>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   FOOTER
──────────────────────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="graph-paper" style={{ borderTop: '1px solid rgba(135,118,102,0.12)', padding: '24px' }}>
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <StarMark size={8} color={P.mojave} rotate={0} spin />
          <span style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: '1.05rem', color: P.coffee }}>aditi.</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: 'Caveat', fontSize: '0.92rem', color: P.muted }}>made with curiosity.</div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.57rem', color: P.muted, marginTop: 2, letterSpacing: '0.05em' }}>C++ · React · Python · AI</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: P.sage, display: 'inline-block', boxShadow: `0 0 5px ${P.sage}` }} />
          <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.57rem', color: P.muted, letterSpacing: '0.07em' }}>ONLINE</span>
        </div>
      </div>
    </footer>
  )
}

/* ────────────────────────────────────────────────────────────────────
   ROOT
──────────────────────────────────────────────────────────────────── */
export default function App() {
  return (
    <div style={{ fontFamily: 'DM Sans, sans-serif', background: P.paper }}>
      <AsteriskCursor />
      <Navbar />
      <Hero />
      <Projects />
      <Skills />
      <About />
      <Journey />
      <Contact />
      <Footer />
    </div>
  )
}
