import {
  useState, useEffect, useRef,
  type CSSProperties, type PointerEvent,
} from 'react'

/* ────────────────────────────────────────────────────────────────────
   PALETTE — warm earthy engineering notebook
──────────────────────────────────────────────────────────────────── */
const P = {
  coffee:    '#4B2615',   // deep primary
  berkeley:  '#7F5E3C',   // secondary brown
  mountain:  '#867679',   // muted gray-mauve
  mojave:    '#B9A583',   // warm sand
  almond:    '#D8C8B1',   // light beige
  sage:      '#9EBD9B',   // dusty sage
  rose:      '#E8D1DC',   // dusty rose (tiny accent only)
  beige:     '#E0DABA',   // warm yellow-beige
  cream:     '#F5F0E7',   // near-white cream
  paper:     '#F7F3EA',   // page base
  ink:       '#2A2318',   // near-black for text
  muted:     '#867679',   // captions / labels
}

/* ────────────────────────────────────────────────────────────────────
   HOOKS
──────────────────────────────────────────────────────────────────── */
function useReveal() {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('visible'); obs.disconnect() } },
      { threshold: 0.12 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return ref
}

function useJourneyLine() {
  const ref = useRef<SVGPathElement>(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('drawn'); obs.disconnect() } },
      { threshold: 0.25 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return ref
}

/* ────────────────────────────────────────────────────────────────────
   SECTION LABEL
──────────────────────────────────────────────────────────────────── */
function Label({ idx, text }: { idx: string; text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
      <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.12em' }}>
        {idx} / {text}
      </span>
      <div style={{ width: 40, height: 1, background: P.almond }} />
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   NAVBAR
──────────────────────────────────────────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', h)
    return () => window.removeEventListener('scroll', h)
  }, [])

  return (
    <nav
      className="fixed top-4 left-1/2 z-50 anim-fade delay-200"
      style={{ transform: 'translateX(-50%)', width: 'min(920px, calc(100vw - 2rem))' }}
    >
      <div
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '10px 20px',
          borderRadius: 14,
          background: scrolled ? 'rgba(247,243,234,0.95)' : 'rgba(247,243,234,0.85)',
          border: `1px solid rgba(135,118,102,${scrolled ? '0.2' : '0.14'})`,
          boxShadow: scrolled ? '0 4px 18px rgba(75,38,21,0.07)' : '0 2px 10px rgba(75,38,21,0.04)',
          transition: 'all 0.3s ease',
        }}
      >
        {/* Logo */}
        <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', fontWeight: 300, fontSize: '1.1rem', color: P.coffee, letterSpacing: '-0.01em' }}>
          aditi.
        </span>

        {/* Links */}
        <div className="hidden md:flex items-center gap-5">
          {['Home','About','Projects','Skills','Journey','Contact'].map(l => (
            <a
              key={l} href={`#${l.toLowerCase()}`}
              className="nav-link"
              style={{ fontSize: '0.82rem', fontWeight: 500, color: P.ink, opacity: 0.65, textDecoration: 'none', transition: 'opacity 0.2s' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = '1' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = '0.65' }}
            >
              {l}
            </a>
          ))}
        </div>

        {/* Status */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: P.sage, display: 'inline-block', boxShadow: `0 0 6px ${P.sage}` }} />
          <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.03em' }}>
            available for internships
          </span>
        </div>
      </div>
    </nav>
  )
}

/* ────────────────────────────────────────────────────────────────────
   HERO — ONE notebook object on the right
──────────────────────────────────────────────────────────────────── */
function NotebookSketch({ tiltX, tiltY }: { tiltX: number; tiltY: number }) {
  return (
    <div
      style={{
        transform: `perspective(900px) rotateY(${tiltX * 3}deg) rotateX(${-tiltY * 2}deg)`,
        transition: 'transform 0.55s cubic-bezier(0.22,1,0.36,1)',
        transformOrigin: 'center center',
      }}
    >
      <div
        style={{
          background: '#FFFEF8',
          border: `1.5px solid rgba(135,118,102,0.22)`,
          borderRadius: 10,
          padding: '28px 30px 32px',
          boxShadow: '4px 6px 28px rgba(75,38,21,0.09), 0 1px 4px rgba(75,38,21,0.05)',
          width: 280,
          position: 'relative',
          /* subtle inner graph lines on the notebook page */
          backgroundImage: `
            linear-gradient(rgba(135,118,102,0.06) 1px, transparent 1px)
          `,
          backgroundSize: '100% 26px',
          backgroundPositionY: '46px',
        }}
      >
        {/* Red margin line */}
        <div style={{ position: 'absolute', left: 44, top: 0, bottom: 0, width: 1, background: 'rgba(232,209,220,0.55)', borderRadius: 1 }} />

        {/* Page tab */}
        <div style={{ position: 'absolute', top: -1, right: 20, width: 40, height: 4, background: P.almond, borderRadius: '0 0 4px 4px' }} />

        {/* Comment header */}
        <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.68rem', color: P.mojave, marginBottom: 20, paddingLeft: 26 }}>
          // things I'm building
        </div>

        {/* Code lines */}
        {[
          { kw: 'const ', name: 'idea',    op: ' = ', val: 'curiosity;' },
          { kw: 'const ', name: 'problem', op: ' = ', val: 'solve(idea);' },
          { kw: 'const ', name: 'result',  op: ' = ', val: 'ship(problem);' },
        ].map(({ kw, name, op, val }) => (
          <div key={name} style={{ fontFamily: 'JetBrains Mono', fontSize: '0.72rem', lineHeight: 2.1, paddingLeft: 26 }}>
            <span style={{ color: P.berkeley }}>{kw}</span>
            <span style={{ color: P.ink }}>{name}</span>
            <span style={{ color: P.mountain }}>{op}</span>
            <span style={{ color: P.coffee }}>{val}</span>
          </div>
        ))}

        {/* Blinking cursor line */}
        <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.72rem', paddingLeft: 26, marginTop: 4 }}>
          <span style={{ color: P.mojave }}>{'>'} </span>
          <span className="cursor-blink" style={{ color: P.berkeley }}>▌</span>
        </div>

        {/* Tiny date annotation bottom-right */}
        <div style={{
          position: 'absolute', bottom: 12, right: 14,
          fontFamily: 'JetBrains Mono', fontSize: '0.55rem', color: P.almond,
          letterSpacing: '0.08em',
        }}>
          2026
        </div>
      </div>
    </div>
  )
}

function Hero() {
  const [cursor, setCursor] = useState({ x: 0.5, y: 0.5 })
  const sectionRef = useRef<HTMLElement>(null)

  const onPointerMove = (e: PointerEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    setCursor({ x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height })
  }

  /* tilt values in -1..1 range */
  const tiltX = cursor.x * 2 - 1
  const tiltY = cursor.y * 2 - 1

  return (
    <section
      id="home"
      ref={sectionRef}
      onPointerMove={onPointerMove}
      className="graph-paper relative min-h-screen flex items-center pt-28 pb-20 overflow-hidden"
    >
      {/* Warm cursor spotlight */}
      <div
        style={{
          position: 'absolute',
          pointerEvents: 'none',
          width: 480,
          height: 480,
          borderRadius: '50%',
          background: `radial-gradient(circle, rgba(185,165,131,0.14) 0%, rgba(185,165,131,0.05) 55%, transparent 70%)`,
          left: `calc(${cursor.x * 100}% - 240px)`,
          top:  `calc(${cursor.y * 100}% - 240px)`,
          transition: 'left 0.45s ease, top 0.45s ease',
          zIndex: 0,
        }}
      />

      <div className="relative z-10 w-full max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-10 items-center">

          {/* ── Left: headline + copy + buttons ── */}
          <div>
            <div
              className="anim-fade delay-300"
              style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.12em', marginBottom: 22 }}
            >
              01 / INTRODUCTION
            </div>

            <h1 style={{ margin: 0, lineHeight: 0.92 }}>
              <div
                className="anim-fade-up delay-400"
                style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,6vw,4.8rem)', color: P.ink, letterSpacing: '-0.03em', lineHeight: 0.92 }}
              >
                BUILDING THINGS
              </div>
              <div
                className="anim-fade-up delay-500"
                style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,6vw,4.8rem)', color: P.ink, letterSpacing: '-0.03em', lineHeight: 0.92 }}
              >
                WITH CODE +
              </div>
              <div
                className="anim-blur-in delay-700"
                style={{
                  fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300,
                  fontSize: 'clamp(3rem,7vw,5.6rem)',
                  letterSpacing: '-0.02em', lineHeight: 1.05,
                  background: `linear-gradient(120deg, ${P.rose} 0%, ${P.mojave} 55%, ${P.berkeley} 100%)`,
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
                }}
              >
                curiosity.
              </div>
            </h1>

            <p
              className="anim-fade-up delay-800"
              style={{ color: P.muted, fontSize: '0.95rem', lineHeight: 1.75, marginTop: 22, maxWidth: 400 }}
            >
              Computer Science student building full-stack applications,<br />
              AI-powered systems and things that make me curious.
            </p>

            <div className="anim-fade-up delay-1000 flex flex-wrap gap-3 mt-8">
              {/* Primary */}
              <a
                href="#projects"
                className="btn-mag"
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 8,
                  background: P.coffee, color: '#FDF8F2',
                  padding: '11px 22px', borderRadius: 8,
                  fontFamily: 'DM Sans', fontWeight: 600, fontSize: '0.78rem', letterSpacing: '0.05em',
                  textDecoration: 'none', border: 'none',
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = P.berkeley }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = P.coffee }}
              >
                VIEW MY WORK →
              </a>
              {/* Secondary */}
              <a
                href="#contact"
                className="btn-mag"
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 8,
                  background: P.cream, color: P.coffee,
                  padding: '11px 22px', borderRadius: 8,
                  fontFamily: 'DM Sans', fontWeight: 600, fontSize: '0.78rem', letterSpacing: '0.05em',
                  textDecoration: 'none', border: `1.5px solid rgba(75,38,21,0.25)`,
                  transition: 'background 0.2s, border-color 0.2s',
                }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.background = P.almond; el.style.borderColor = 'rgba(75,38,21,0.4)' }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.background = P.cream; el.style.borderColor = 'rgba(75,38,21,0.25)' }}
              >
                LET'S CONNECT →
              </a>
            </div>
          </div>

          {/* ── Right: ONE notebook object ── */}
          <div
            className="anim-fade-up delay-900 hidden md:flex justify-center items-center"
          >
            <NotebookSketch tiltX={tiltX} tiltY={tiltY} />
          </div>

        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   PROJECTS
──────────────────────────────────────────────────────────────────── */
const PROJECTS = [
  {
    num: '01', name: 'SkillSwap',
    desc: 'Peer-to-peer skill exchange platform connecting learners and experts in real time.',
    tech: ['React', 'Node.js', 'MongoDB', 'Express'],
    /* warm beige / dusty rose — paper-colored with a hint of rose */
    bg: '#FFFBF7', border: `rgba(232,209,220,0.55)`, accent: P.rose,
    accentText: P.berkeley, span: 2,
  },
  {
    num: '02', name: 'Verity',
    desc: 'Barcode scanning and real-time price comparison application for smart shopping.',
    tech: ['Python', 'FastAPI', 'React', 'PostgreSQL'],
    /* muted sage / cream */
    bg: '#F6FAF6', border: `rgba(158,189,155,0.45)`, accent: P.sage,
    accentText: '#3E5C3C', span: 1,
  },
  {
    num: '03', name: 'TaskPilot',
    desc: 'AI-powered task intelligence system that prioritizes, schedules and learns your workflow.',
    tech: ['Python', 'NLP', 'React', 'TypeScript'],
    /* warm almond / brown */
    bg: '#FAF6EF', border: `rgba(185,165,131,0.45)`, accent: P.almond,
    accentText: P.coffee, span: 1,
  },
]

function ProjectCard({ p }: { p: typeof PROJECTS[0] }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        gridColumn: `span ${p.span}`,
        background: hov ? p.bg : '#FFFEF9',
        border: `1.5px solid ${hov ? p.border : 'rgba(135,118,102,0.14)'}`,
        borderRadius: 14,
        padding: '30px 26px',
        transform: hov ? 'translateY(-5px)' : 'none',
        boxShadow: hov ? '0 14px 36px rgba(75,38,21,0.07)' : '0 2px 8px rgba(75,38,21,0.03)',
        transition: 'all 0.32s cubic-bezier(0.22,1,0.36,1)',
        cursor: 'default',
      }}
    >
      {/* Top accent strip */}
      <div style={{
        height: 2, borderRadius: 4, marginBottom: 22,
        background: p.accent,
        width: hov ? '100%' : '32%',
        transition: 'width 0.4s ease',
      }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.6rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 8 }}>
            {p.num} — PROJECT
          </div>
          <h3 style={{ fontFamily: 'DM Sans', fontWeight: 700, fontSize: '1.5rem', color: P.ink, letterSpacing: '-0.02em', marginBottom: 10 }}>
            {p.name}
          </h3>
          <p style={{ color: P.muted, fontSize: '0.88rem', lineHeight: 1.65, maxWidth: 460 }}>{p.desc}</p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 10 }}>
          <span style={{ transform: hov ? 'translate(3px,-2px)' : 'none', transition: 'transform 0.22s ease', fontSize: '1.1rem', color: p.accentText }}>→</span>
          <div style={{ display: 'flex', gap: 6 }}>
            {['GitHub','Live Demo'].map(l => (
              <a key={l} href="#" style={{ fontSize: '0.65rem', color: P.muted, padding: '3px 9px', border: `1px solid rgba(135,118,102,0.2)`, borderRadius: 5, textDecoration: 'none', fontFamily: 'JetBrains Mono', letterSpacing: '0.03em' }}>{l}</a>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 20 }}>
        {p.tech.map(t => (
          <span key={t} style={{ fontSize: '0.67rem', color: P.berkeley, padding: '3px 9px', background: `rgba(127,94,60,0.07)`, borderRadius: 5, fontFamily: 'JetBrains Mono', letterSpacing: '0.03em' }}>{t}</span>
        ))}
      </div>
    </div>
  )
}

function Projects() {
  const ref = useReveal()
  return (
    <section id="projects" className="graph-paper py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="02" text="SELECTED WORK" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 44 }}>
            things I've built.
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 18 }}>
          {PROJECTS.map(p => <ProjectCard key={p.num} p={p} />)}
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SKILLS — large square notebook tiles
──────────────────────────────────────────────────────────────────── */
const SKILLS = [
  { idx: '01', title: 'LANGUAGES', items: ['C++','Python','Java','JavaScript','TypeScript'], bg: '#FDFAF3', border: 'rgba(185,165,131,0.45)', dot: P.mojave },
  { idx: '02', title: 'FRONTEND',  items: ['React','Vite','TypeScript','Tailwind CSS'],      bg: '#F9FBFA', border: 'rgba(158,189,155,0.45)', dot: P.sage   },
  { idx: '03', title: 'BACKEND',   items: ['Node.js','Express.js','FastAPI'],                bg: '#FAF6F0', border: 'rgba(127,94,60,0.28)',   dot: P.berkeley },
  { idx: '04', title: 'AI / DATA', items: ['Python','NumPy','Pandas','Scikit-learn','NLP'],  bg: '#FDF9F7', border: 'rgba(232,209,220,0.55)', dot: P.rose   },
  { idx: '05', title: 'DATABASES', items: ['MongoDB','PostgreSQL','MySQL'],                  bg: '#FAF8F2', border: 'rgba(224,218,186,0.6)',  dot: P.beige  },
  { idx: '06', title: 'TOOLS',     items: ['Git','GitHub','Docker','Figma'],                 bg: '#F8FAFA', border: 'rgba(158,189,155,0.35)', dot: P.sage   },
]

function SkillTile({ s }: { s: typeof SKILLS[0] }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? s.bg : '#FFFEF9',
        border: `1.5px solid ${hov ? s.border : 'rgba(135,118,102,0.11)'}`,
        borderRadius: 14,
        padding: '26px 22px',
        transform: hov ? `translateY(-6px) rotate(${s.idx <= '03' ? 0.35 : -0.35}deg)` : 'none',
        boxShadow: hov ? '0 18px 44px rgba(75,38,21,0.07)' : '0 1px 6px rgba(75,38,21,0.03)',
        transition: 'all 0.32s cubic-bezier(0.22,1,0.36,1)',
        cursor: 'default',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Decorative circle */}
      <div style={{
        position: 'absolute', bottom: -18, right: -18,
        width: 70, height: 70, borderRadius: '50%',
        border: `1.5px solid ${s.dot}`,
        opacity: hov ? 0.5 : 0.15,
        transform: hov ? 'scale(1.25)' : 'scale(1)',
        transition: 'all 0.4s ease',
      }} />
      <div style={{
        position: 'absolute', bottom: 10, right: 12,
        fontFamily: 'JetBrains Mono', fontSize: '0.55rem', color: s.dot,
        opacity: hov ? 1 : 0.35,
        transform: hov ? 'translateX(3px)' : 'none',
        transition: 'all 0.25s ease',
      }}>→</div>

      <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.58rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 12 }}>{s.idx}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 18 }}>
        <div style={{ width: 7, height: 7, borderRadius: '50%', background: s.dot, transition: 'transform 0.3s', transform: hov ? 'scale(1.3)' : 'scale(1)' }} />
        <span style={{ fontFamily: 'DM Sans', fontWeight: 700, fontSize: '0.88rem', color: P.ink, letterSpacing: '0.06em' }}>{s.title}</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, transform: hov ? 'translateY(-2px)' : 'none', transition: 'transform 0.3s ease' }}>
        {s.items.map(item => (
          <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 3, height: 3, borderRadius: '50%', background: s.dot, flexShrink: 0 }} />
            <span style={{ fontSize: '0.83rem', color: P.ink }}>{item}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function Skills() {
  const ref = useReveal()
  return (
    <section id="skills" className="graph-paper py-24 px-6" style={{ background: '#F2EDE3' }}>
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="03" text="TOOLBOX" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 44 }}>
            things I build with.
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px,1fr))', gap: 18 }}>
          {SKILLS.map(s => <SkillTile key={s.idx} s={s} />)}
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   ABOUT
──────────────────────────────────────────────────────────────────── */
const INFO_CARDS: { label: string; items: string[]; bg: string }[] = [
  { label: 'EDUCATION', items: ['B.Tech Computer Science'],                       bg: '#FAF6EF' },
  { label: 'FOCUS',     items: ['Software Engineering','AI','Full Stack'],        bg: '#F6FAF6' },
  { label: 'INTERESTS', items: ['Building','Learning','Experimenting'],           bg: '#FAF8F2' },
  { label: 'CURRENTLY', items: ['Improving DSA','Building projects','Exploring AI'], bg: '#FDF9F7' },
]

function About() {
  const ref = useReveal()
  return (
    <section id="about" className="graph-paper py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="04" text="ABOUT" />
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-start mt-8">
          {/* Left */}
          <div>
            <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(1.7rem,4vw,2.6rem)', color: P.ink, lineHeight: 1.3, letterSpacing: '-0.02em', marginBottom: 20 }}>
              I like understanding<br />how things work —<br />and then building them.
            </h2>
            <p style={{ color: P.muted, lineHeight: 1.75, fontSize: '0.92rem', maxWidth: 400 }}>
              I'm Aditi, a Computer Science student with a bias for building.
              Whether it's wiring together a full-stack app, experimenting with AI,
              or solving a tricky algorithmic puzzle — I gravitate toward problems
              that reward curiosity. I believe the best software is both{' '}
              <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', color: P.ink }}>useful</span>{' '}
              and{' '}
              <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', color: P.ink }}>beautiful</span>.
            </p>
            {/* Annotation */}
            <div style={{ marginTop: 24, display: 'inline-block', padding: '10px 14px', border: `1px solid rgba(185,165,131,0.4)`, borderRadius: 7, background: '#FAF6EF' }}>
              <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.6rem', color: P.mojave, letterSpacing: '0.07em' }}>
                // currently: B.Tech CS · Year 2 · India
              </div>
            </div>
          </div>

          {/* Right: paper note cards */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {INFO_CARDS.map(card => (
              <div key={card.label} style={{ background: card.bg, border: `1.5px solid rgba(135,118,102,0.12)`, borderRadius: 11, padding: '16px 14px' }}>
                <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.58rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 10 }}>{card.label}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                  {card.items.map(i => (
                    <div key={i} style={{ fontSize: '0.8rem', color: P.ink, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ width: 3, height: 3, borderRadius: '50%', background: P.mojave, flexShrink: 0 }} />
                      {i}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   JOURNEY
──────────────────────────────────────────────────────────────────── */
const TIMELINE = [
  { year: '2024', tag: 'LEARNING', desc: 'Foundations in CS — data structures, algorithms, and first real projects.', color: P.mojave },
  { year: '2025', tag: 'BUILDING', desc: 'Full-stack apps, AI experiments, open source contributions.',            color: P.sage    },
  { year: '2026', tag: 'SHIPPING', desc: 'Real products. SkillSwap, Verity, TaskPilot — and more.',                color: P.berkeley },
  { year: 'NEXT', tag: '?',        desc: 'Internships, collaborations, and whatever problem catches my curiosity.', color: P.rose   },
]

function Journey() {
  const ref = useReveal()
  const lineRef = useJourneyLine()

  return (
    <section id="journey" className="graph-paper py-24 px-6" style={{ background: '#F2EDE3' }}>
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="05" text="JOURNEY" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 52 }}>
            where I've been.
          </h2>
        </div>

        <div style={{ position: 'relative', paddingLeft: 34 }}>
          {/* SVG line — coffee brown */}
          <svg
            style={{ position: 'absolute', left: 8, top: 8, width: 2, height: 'calc(100% - 16px)', overflow: 'visible' }}
            viewBox="0 0 2 600"
            preserveAspectRatio="none"
          >
            <path
              ref={lineRef}
              d="M1 0 L1 600"
              stroke={P.berkeley}
              strokeWidth="1.5"
              fill="none"
              className="journey-line"
            />
          </svg>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 42 }}>
            {TIMELINE.map((t, i) => (
              <div key={t.year} style={{ position: 'relative', display: 'flex', alignItems: 'flex-start', gap: 22 }}>
                {/* Node */}
                <div style={{
                  position: 'absolute', left: -34, top: 5,
                  width: 12, height: 12, borderRadius: '50%',
                  background: t.color,
                  border: `2px solid #F2EDE3`,
                  boxShadow: `0 0 10px ${t.color}88`,
                  zIndex: 2,
                  animationDelay: `${i * 0.15}s`,
                }} />
                <div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 7 }}>
                    <span style={{ fontFamily: 'JetBrains Mono', fontWeight: 500, fontSize: '1.05rem', color: P.ink, letterSpacing: '-0.01em' }}>{t.year}</span>
                    <span style={{ fontFamily: 'DM Sans', fontWeight: 700, fontSize: '0.7rem', letterSpacing: '0.09em', color: t.color, padding: '2px 9px', background: `${t.color}20`, borderRadius: 20 }}>
                      {t.tag}
                    </span>
                  </div>
                  <p style={{ color: P.muted, fontSize: '0.88rem', lineHeight: 1.65, maxWidth: 460 }}>{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   CONTACT
──────────────────────────────────────────────────────────────────── */
function Contact() {
  const ref = useReveal()
  return (
    <section id="contact" className="graph-paper py-28 px-6 relative overflow-hidden">
      {/* Warm glow */}
      <div style={{ position: 'absolute', top: '40%', left: '50%', transform: 'translate(-50%,-50%)', width: 500, height: 360, borderRadius: '50%', background: `radial-gradient(ellipse, rgba(185,165,131,0.13) 0%, transparent 68%)`, pointerEvents: 'none' }} />

      <div className="max-w-5xl mx-auto relative z-10">
        <div ref={ref} className="reveal text-center">
          <Label idx="06" text="CONTACT" />

          <h2 style={{
            fontFamily: 'DM Sans, sans-serif', fontWeight: 700,
            fontSize: 'clamp(2.6rem,7vw,5.5rem)',
            color: P.ink, letterSpacing: '-0.04em', lineHeight: 0.9,
            marginTop: 14, marginBottom: 20,
          }}>
            LET'S BUILD<br />
            <span style={{
              fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300,
              letterSpacing: '-0.02em',
              background: `linear-gradient(120deg, ${P.rose} 0%, ${P.mojave} 60%, ${P.berkeley} 100%)`,
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            }}>SOMETHING</span><br />
            INTERESTING.
          </h2>

          <p style={{ color: P.muted, fontSize: '0.82rem', letterSpacing: '0.09em', marginBottom: 34, fontFamily: 'JetBrains Mono' }}>
            open to internships + collaborations
          </p>

          <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 52 }}>
            {[{ label: 'GitHub', href: 'https://github.com' }, { label: 'LinkedIn', href: 'https://linkedin.com' }, { label: 'Email', href: 'mailto:aditi@example.com' }].map(({ label, href }) => (
              <a key={label} href={href} className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 7,
                padding: '10px 22px', borderRadius: 9,
                border: `1.5px solid rgba(135,118,102,0.2)`,
                color: P.ink, fontSize: '0.82rem', fontWeight: 500,
                letterSpacing: '0.04em', textDecoration: 'none',
                background: '#FFFEF9',
                transition: 'all 0.22s ease',
              }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = P.berkeley; el.style.background = '#FAF6EF' }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'rgba(135,118,102,0.2)'; el.style.background = '#FFFEF9' }}
              >
                {label} →
              </a>
            ))}
          </div>

          {/* Mini terminal */}
          <div style={{
            display: 'inline-block',
            background: '#2A2318', color: P.mojave,
            borderRadius: 9, padding: '11px 18px',
            fontFamily: 'JetBrains Mono', fontSize: '0.7rem',
          }}>
            {'$ echo "hello"'}
            <span className="cursor-blink" style={{ color: P.almond, marginLeft: 4 }}>▌</span>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   FOOTER
──────────────────────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="graph-paper" style={{ borderTop: `1px solid rgba(135,118,102,0.14)`, padding: '24px' }}>
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
        <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', fontWeight: 300, fontSize: '1.05rem', color: P.coffee }}>
          aditi.
        </span>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '0.74rem', color: P.muted }}>Designed + built with curiosity.</div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.58rem', color: P.muted, marginTop: 2, letterSpacing: '0.05em' }}>C++ · React · Python · AI</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: P.sage, display: 'inline-block', boxShadow: `0 0 5px ${P.sage}` }} />
          <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.57rem', color: P.muted, letterSpacing: '0.07em' }}>SYSTEM_STATUS: ONLINE</span>
        </div>
      </div>
    </footer>
  )
}

/* ────────────────────────────────────────────────────────────────────
   ROOT
──────────────────────────────────────────────────────────────────── */
export default function App() {
  return (
    <div style={{ fontFamily: 'DM Sans, sans-serif', background: P.paper }}>
      <Navbar />
      <Hero />
      <Projects />
      <Skills />
      <About />
      <Journey />
      <Contact />
      <Footer />
    </div>
  )
}
