import {
  useState, useEffect, useRef,
  type CSSProperties, type PointerEvent,
} from 'react'

/* ────────────────────────────────────────────────────────────────────
   PALETTE
──────────────────────────────────────────────────────────────────── */
const P = {
  coffee:     '#4B2615',
  berkeley:   '#7F5E3C',
  mountain:   '#867679',
  mojave:     '#B9A583',
  almond:     '#D8C8B1',
  warm_sand:  '#D8C6A0',
  sage:       '#9EBD9B',
  muted_sage: '#ACBDB7',
  deep_green: '#4E635E',
  charcoal:   '#676D6B',
  pale_butter:'#ECE9BE',
  dusty_rose: '#E8D1DC',
  dusty_pink: '#D6B1BB',
  blue_gray:  '#9CABC8',
  pale_blue:  '#CFDBE7',
  cream:      '#F5F0E7',
  paper:      '#F7F3EA',
  ink:        '#2A2318',
  muted:      '#867679',
}

/* ────────────────────────────────────────────────────────────────────
   HOOKS
──────────────────────────────────────────────────────────────────── */
function useReveal() {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('visible'); obs.disconnect() } },
      { threshold: 0.12 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return ref
}

function useJourneyLine() {
  const ref = useRef<SVGPathElement>(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { el.classList.add('drawn'); obs.disconnect() } },
      { threshold: 0.25 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return ref
}

/* ────────────────────────────────────────────────────────────────────
   CUSTOM CURSOR
──────────────────────────────────────────────────────────────────── */
function CustomCursor() {
  const dotRef  = useRef<HTMLDivElement>(null)
  const ringRef = useRef<HTMLDivElement>(null)
  const [label, setLabel]       = useState('')
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    let raf = 0
    let rx = -200, ry = -200
    let tx = -200, ty = -200

    const onMove = (e: MouseEvent) => {
      rx = e.clientX; ry = e.clientY
      if (dotRef.current) {
        dotRef.current.style.left = rx + 'px'
        dotRef.current.style.top  = ry + 'px'
      }
      // Determine cursor type
      const el = e.target as HTMLElement
      if (el.closest('.skill-tile')) { setLabel('✦'); setExpanded(true) }
      else if (el.closest('a, button')) { setLabel('→'); setExpanded(true) }
      else { setLabel(''); setExpanded(false) }
    }

    const animate = () => {
      tx += (rx - tx) * 0.11
      ty += (ry - ty) * 0.11
      if (ringRef.current) {
        ringRef.current.style.left = tx + 'px'
        ringRef.current.style.top  = ty + 'px'
      }
      raf = requestAnimationFrame(animate)
    }

    raf = requestAnimationFrame(animate)
    document.addEventListener('mousemove', onMove)
    return () => { document.removeEventListener('mousemove', onMove); cancelAnimationFrame(raf) }
  }, [])

  return (
    <>
      {/* Lagging ring */}
      <div ref={ringRef} style={{
        position: 'fixed', pointerEvents: 'none', zIndex: 9998,
        width: expanded ? 36 : 22,
        height: expanded ? 36 : 22,
        borderRadius: '50%',
        border: `1px solid rgba(127,94,60,${expanded ? '0.35' : '0.18'})`,
        transform: 'translate(-50%,-50%)',
        transition: 'width 0.2s, height 0.2s, border-color 0.2s',
      }}/>
      {/* Dot */}
      <div ref={dotRef} style={{
        position: 'fixed', pointerEvents: 'none', zIndex: 9999,
        width: expanded ? 26 : 7,
        height: expanded ? 26 : 7,
        borderRadius: '50%',
        background: expanded ? 'transparent' : P.berkeley,
        border: expanded ? `1.5px solid ${P.berkeley}` : 'none',
        transform: 'translate(-50%,-50%)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'width 0.18s, height 0.18s, background 0.18s',
      }}>
        {label && <span style={{ fontSize: '0.72rem', color: P.berkeley, lineHeight: 1 }}>{label}</span>}
      </div>
    </>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SIGNATURE STAR MOTIF — Aditi's recurring mark
──────────────────────────────────────────────────────────────────── */
function StarMark({
  size = 9,
  color = P.mojave,
  rotate = 0,
  spin = false,
}: {
  size?: number; color?: string; rotate?: number; spin?: boolean
}) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 10 10"
      style={{ display: 'inline-block', transform: `rotate(${rotate}deg)`, flexShrink: 0 }}
      className={spin ? 'star-spin' : ''}
    >
      <line x1="5" y1="0.5" x2="5" y2="9.5" stroke={color} strokeWidth="1.1" strokeLinecap="round"/>
      <line x1="0.5" y1="5" x2="9.5" y2="5" stroke={color} strokeWidth="1.1" strokeLinecap="round"/>
      <line x1="1.5" y1="1.5" x2="8.5" y2="8.5" stroke={color} strokeWidth="0.9" strokeLinecap="round"/>
      <line x1="8.5" y1="1.5" x2="1.5" y2="8.5" stroke={color} strokeWidth="0.9" strokeLinecap="round"/>
    </svg>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SECTION LABEL
──────────────────────────────────────────────────────────────────── */
function Label({ idx, text }: { idx: string; text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
      <StarMark size={7} color={P.mojave} rotate={22} />
      <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.12em' }}>
        {idx} / {text}
      </span>
      <div style={{ width: 36, height: 1, background: P.almond }} />
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   TECH LOGOS
──────────────────────────────────────────────────────────────────── */
function TechLogo({ name, color }: { name: string; color: string }) {
  const s: CSSProperties = { display: 'block' }
  switch (name) {
    case 'React':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <ellipse cx="30" cy="30" rx="27" ry="10" stroke={color} strokeWidth="1.8"/>
          <ellipse cx="30" cy="30" rx="27" ry="10" stroke={color} strokeWidth="1.8" transform="rotate(60 30 30)"/>
          <ellipse cx="30" cy="30" rx="27" ry="10" stroke={color} strokeWidth="1.8" transform="rotate(120 30 30)"/>
          <circle cx="30" cy="30" r="3.5" fill={color}/>
        </svg>
      )
    case 'Python':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <path d="M30 8 C22 8 16 13 16 21 L16 26 L44 26 L44 30 L16 30 L16 40 C16 48 22 52 30 52 C38 52 44 47 44 40 L44 34 L16 34 L16 30" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
          <circle cx="23" cy="20" r="2.5" fill={color}/>
          <circle cx="37" cy="40" r="2.5" fill={color}/>
        </svg>
      )
    case 'TypeScript':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s}>
          <rect x="8" y="8" width="44" height="44" rx="7" fill={color} opacity="0.15"/>
          <text x="30" y="39" textAnchor="middle" fontFamily="JetBrains Mono" fontWeight="700" fontSize="20" fill={color}>TS</text>
        </svg>
      )
    case 'JavaScript':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s}>
          <rect x="8" y="8" width="44" height="44" rx="7" fill={color} opacity="0.2"/>
          <text x="30" y="39" textAnchor="middle" fontFamily="JetBrains Mono" fontWeight="700" fontSize="20" fill={color}>JS</text>
        </svg>
      )
    case 'C++':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s}>
          <text x="8" y="37" fontFamily="JetBrains Mono" fontWeight="700" fontSize="19" fill={color}>C++</text>
          <line x1="8" y1="43" x2="40" y2="43" stroke={color} strokeWidth="1.2" opacity="0.35"/>
        </svg>
      )
    case 'Java':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <path d="M24 14 Q30 8 36 14 L36 36 Q36 44 30 48 Q24 44 24 36 Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
          <path d="M18 52 Q30 47 42 52" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
        </svg>
      )
    case 'Node.js':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <path d="M30 10 L48 20 L48 40 L30 50 L12 40 L12 20 Z" stroke={color} strokeWidth="1.8" strokeLinejoin="round"/>
          <path d="M30 22 L30 38" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
          <circle cx="30" cy="30" r="3" fill={color}/>
        </svg>
      )
    case 'Express':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s}>
          <text x="7" y="33" fontFamily="JetBrains Mono" fontSize="11" fontWeight="500" fill={color} letterSpacing="1">exp</text>
          <path d="M7 40 Q20 36 33 40 Q46 44 53 40" stroke={color} strokeWidth="1.3" fill="none" strokeLinecap="round"/>
        </svg>
      )
    case 'FastAPI':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <circle cx="30" cy="30" r="20" stroke={color} strokeWidth="1.8"/>
          <path d="M30 14 L24 30 L30 30 L24 46" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      )
    case 'MongoDB':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <path d="M30 8 Q39 20 39 33 Q39 45 30 52 Q21 45 21 33 Q21 20 30 8 Z" stroke={color} strokeWidth="1.8"/>
          <line x1="30" y1="40" x2="30" y2="54" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
        </svg>
      )
    case 'PostgreSQL':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <ellipse cx="30" cy="18" rx="18" ry="8" stroke={color} strokeWidth="1.8"/>
          <path d="M12 18 L12 38 Q12 50 30 50 Q48 50 48 38 L48 18" stroke={color} strokeWidth="1.8"/>
          <line x1="30" y1="10" x2="30" y2="50" stroke={color} strokeWidth="1.2" opacity="0.35"/>
        </svg>
      )
    case 'MySQL':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <path d="M12 20 L12 40 Q12 48 30 48" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
          <path d="M48 20 L48 28 Q48 36 36 40" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
          <ellipse cx="30" cy="20" rx="18" ry="7" stroke={color} strokeWidth="1.8"/>
        </svg>
      )
    case 'Git':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <circle cx="18" cy="18" r="5" stroke={color} strokeWidth="1.8"/>
          <circle cx="42" cy="18" r="5" stroke={color} strokeWidth="1.8"/>
          <circle cx="18" cy="44" r="5" stroke={color} strokeWidth="1.8"/>
          <line x1="18" y1="23" x2="18" y2="39" stroke={color} strokeWidth="1.8"/>
          <path d="M23 18 Q30 18 30 26 L30 44 L37 44" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      )
    case 'Docker':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <rect x="10" y="28" width="40" height="16" rx="4" stroke={color} strokeWidth="1.8"/>
          {[14,22,30,38].map(x => (
            <rect key={x} x={x} y="20" width="6" height="8" rx="1.5" stroke={color} strokeWidth="1.4"/>
          ))}
          {[18,26].map(x => (
            <rect key={x} x={x} y="12" width="6" height="8" rx="1.5" stroke={color} strokeWidth="1.4"/>
          ))}
          <path d="M50 32 Q56 28 54 24 Q52 22 48 24" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
        </svg>
      )
    case 'Figma':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <rect x="20" y="8" width="20" height="20" rx="10" stroke={color} strokeWidth="1.8"/>
          <rect x="20" y="28" width="20" height="20" rx="10" stroke={color} strokeWidth="1.8"/>
          <rect x="20" y="8" width="10" height="20" stroke={color} strokeWidth="1.8" fill={color} opacity="0.13"/>
          <circle cx="40" cy="28" r="10" stroke={color} strokeWidth="1.8"/>
        </svg>
      )
    case 'Tailwind':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <path d="M14 28 Q18 18 26 20 Q30 21 30 28 Q34 18 42 20 Q46 22 46 32" stroke={color} strokeWidth="2" strokeLinecap="round"/>
          <path d="M14 38 Q18 28 26 30 Q30 31 30 38 Q34 28 42 30 Q46 32 46 42" stroke={color} strokeWidth="2" strokeLinecap="round"/>
        </svg>
      )
    case 'NumPy':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <rect x="10" y="10" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8"/>
          <rect x="33" y="10" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8"/>
          <rect x="10" y="33" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8"/>
          <rect x="33" y="33" width="17" height="17" rx="2" stroke={color} strokeWidth="1.8" fill={color} opacity="0.15"/>
        </svg>
      )
    case 'Pandas':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <rect x="12" y="10" width="10" height="40" rx="5" stroke={color} strokeWidth="1.8"/>
          <rect x="38" y="10" width="10" height="40" rx="5" stroke={color} strokeWidth="1.8"/>
          <rect x="22" y="22" width="16" height="16" rx="3" stroke={color} strokeWidth="1.5" opacity="0.5"/>
        </svg>
      )
    case 'Scikit':
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s} fill="none">
          <circle cx="30" cy="30" r="18" stroke={color} strokeWidth="1.8"/>
          <path d="M20 30 Q30 18 40 30 Q30 42 20 30 Z" stroke={color} strokeWidth="1.5" fill={color} opacity="0.12"/>
        </svg>
      )
    default:
      return (
        <svg viewBox="0 0 60 60" width="34" height="34" style={s}>
          <text x="30" y="36" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="13" fontWeight="500" fill={color}>{name.slice(0,3)}</text>
        </svg>
      )
  }
}

/* ────────────────────────────────────────────────────────────────────
   NAVBAR
──────────────────────────────────────────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', h)
    return () => window.removeEventListener('scroll', h)
  }, [])
  return (
    <nav
      className="fixed top-4 left-1/2 z-50 anim-fade delay-200"
      style={{ transform: 'translateX(-50%)', width: 'min(920px, calc(100vw - 2rem))' }}
    >
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '10px 20px', borderRadius: 14,
        background: scrolled ? 'rgba(247,243,234,0.97)' : 'rgba(247,243,234,0.88)',
        border: `1px solid rgba(135,118,102,${scrolled ? '0.22' : '0.14'})`,
        boxShadow: scrolled ? '0 4px 18px rgba(75,38,21,0.08)' : '0 2px 10px rgba(75,38,21,0.04)',
        backdropFilter: 'blur(8px)',
        transition: 'all 0.3s ease',
      }}>
        <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', fontWeight: 300, fontSize: '1.1rem', color: P.coffee }}>
          aditi.
        </span>
        <div className="hidden md:flex items-center gap-5">
          {['Home','About','Projects','Skills','Journey','Contact'].map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} className="nav-link"
              style={{ fontSize: '0.82rem', fontWeight: 500, color: P.ink, opacity: 0.65, textDecoration: 'none', transition: 'opacity 0.2s' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = '1' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = '0.65' }}
            >{l}</a>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: P.sage, display: 'inline-block', boxShadow: `0 0 6px ${P.sage}` }} />
          <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.03em' }}>available for internships</span>
        </div>
      </div>
    </nav>
  )
}

/* ────────────────────────────────────────────────────────────────────
   HERO NOTEBOOK
──────────────────────────────────────────────────────────────────── */
function NotebookSketch({ tiltX, tiltY }: { tiltX: number; tiltY: number }) {
  return (
    <div style={{
      transform: `perspective(900px) rotateY(${tiltX * 3}deg) rotateX(${-tiltY * 2}deg)`,
      transition: 'transform 0.55s cubic-bezier(0.22,1,0.36,1)',
    }}>
      <div style={{
        background: '#FFFEF8',
        border: `1.5px solid rgba(135,118,102,0.2)`,
        borderRadius: 10,
        padding: '26px 28px 28px',
        boxShadow: '4px 8px 32px rgba(75,38,21,0.1), 0 1px 4px rgba(75,38,21,0.05)',
        width: 288,
        position: 'relative',
        backgroundImage: `linear-gradient(rgba(135,118,102,0.055) 1px, transparent 1px)`,
        backgroundSize: '100% 26px',
        backgroundPositionY: '44px',
      }}>
        {/* Red margin */}
        <div style={{ position: 'absolute', left: 44, top: 0, bottom: 0, width: 1, background: 'rgba(214,177,187,0.55)' }} />
        {/* Page tab */}
        <div style={{ position: 'absolute', top: -1, right: 22, width: 38, height: 4, background: P.almond, borderRadius: '0 0 4px 4px' }} />
        {/* Tape */}
        <div style={{ position: 'absolute', top: 6, left: -10, width: 50, height: 11, background: 'rgba(236,233,190,0.65)', borderRadius: 2, transform: 'rotate(-5deg)' }} />

        {/* Handwritten annotation */}
        <div style={{ fontFamily: 'Caveat', fontSize: '0.92rem', color: P.deep_green, marginBottom: 16, paddingLeft: 26 }}>
          // currently building →
        </div>

        {[
          { kw: 'const ', name: 'idea',    op: ' = ', val: 'curiosity;' },
          { kw: 'const ', name: 'problem', op: ' = ', val: 'solve(idea);' },
          { kw: 'const ', name: 'result',  op: ' = ', val: 'ship(it);' },
        ].map(({ kw, name, op, val }) => (
          <div key={name} style={{ fontFamily: 'JetBrains Mono', fontSize: '0.71rem', lineHeight: 2.1, paddingLeft: 26 }}>
            <span style={{ color: P.deep_green }}>{kw}</span>
            <span style={{ color: P.ink }}>{name}</span>
            <span style={{ color: P.mountain }}>{op}</span>
            <span style={{ color: P.coffee }}>{val}</span>
          </div>
        ))}

        <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.71rem', paddingLeft: 26, marginTop: 4 }}>
          <span style={{ color: P.mojave }}>{'>'} </span>
          <span className="cursor-blink" style={{ color: P.deep_green }}>▌</span>
        </div>

        <div style={{ marginTop: 16, paddingLeft: 26, borderTop: `1px dashed rgba(172,189,183,0.4)`, paddingTop: 10 }}>
          <span style={{ fontFamily: 'Caveat', fontSize: '0.82rem', color: P.mountain }}>
            idea → build → break → fix → ship
          </span>
        </div>

        {/* Circled year + star mark */}
        <div style={{
          position: 'absolute', bottom: 10, right: 12, display: 'flex', alignItems: 'center', gap: 5,
        }}>
          <StarMark size={7} color={P.almond} rotate={15} />
          <span style={{ fontFamily: 'Caveat', fontSize: '0.72rem', color: P.almond, border: `1px solid rgba(185,165,131,0.3)`, borderRadius: '50%', width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>'26</span>
        </div>
      </div>
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   HERO
──────────────────────────────────────────────────────────────────── */
function Hero() {
  const [cursor, setCursor] = useState({ x: 0.5, y: 0.5 })
  const sectionRef = useRef<HTMLElement>(null)
  const onPointerMove = (e: PointerEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    setCursor({ x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height })
  }
  const tiltX = cursor.x * 2 - 1
  const tiltY = cursor.y * 2 - 1
  return (
    <section id="home" ref={sectionRef} onPointerMove={onPointerMove}
      className="graph-paper relative min-h-screen flex items-center pt-28 pb-20 overflow-hidden"
    >
      {/* Multi-tone cursor glow */}
      <div style={{
        position: 'absolute', pointerEvents: 'none',
        width: 520, height: 520, borderRadius: '50%',
        background: `radial-gradient(circle, rgba(172,189,183,0.1) 0%, rgba(232,209,220,0.07) 38%, rgba(185,165,131,0.05) 60%, transparent 72%)`,
        left: `calc(${cursor.x * 100}% - 260px)`,
        top:  `calc(${cursor.y * 100}% - 260px)`,
        transition: 'left 0.5s ease, top 0.5s ease', zIndex: 0,
      }} />
      <div className="relative z-10 w-full max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="anim-fade delay-300" style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 22 }}>
              <StarMark size={7} color={P.muted_sage} rotate={0} />
              <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.62rem', color: P.muted, letterSpacing: '0.12em' }}>01 / INTRODUCTION</span>
            </div>
            <h1 style={{ margin: 0, lineHeight: 0.92 }}>
              <div className="anim-fade-up delay-400" style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,6vw,4.8rem)', color: P.ink, letterSpacing: '-0.03em', lineHeight: 0.92 }}>
                BUILDING THINGS
              </div>
              <div className="anim-fade-up delay-500" style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,6vw,4.8rem)', color: P.ink, letterSpacing: '-0.03em', lineHeight: 0.92 }}>
                WITH CODE +
              </div>
              <div className="anim-blur-in delay-700" style={{
                fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300,
                fontSize: 'clamp(3rem,7vw,5.6rem)', letterSpacing: '-0.02em', lineHeight: 1.05,
                background: `linear-gradient(115deg, ${P.dusty_pink} 0%, ${P.mojave} 48%, ${P.deep_green} 100%)`,
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
              }}>
                curiosity.
              </div>
            </h1>

            {/* Handwritten keep-learning annotation */}
            <div className="anim-fade-up delay-800" style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 14, marginBottom: 8 }}>
              <span style={{ fontFamily: 'Caveat', fontSize: '0.92rem', color: P.muted_sage }}>keep learning</span>
              <svg viewBox="0 0 32 10" width="32" height="10" fill="none">
                <path d="M2 5 Q10 2 20 5 Q26 7 30 5" stroke={P.muted_sage} strokeWidth="1.2" strokeLinecap="round"/>
                <path d="M26 2 L30 5 L26 8" stroke={P.muted_sage} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>

            <p className="anim-fade-up delay-800" style={{ color: P.muted, fontSize: '0.95rem', lineHeight: 1.75, marginTop: 10, maxWidth: 400 }}>
              Computer Science student building full-stack applications,<br />
              AI-powered systems and things that make me curious.
            </p>
            <div className="anim-fade-up delay-1000 flex flex-wrap gap-3 mt-8">
              <a href="#projects" className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: P.coffee, color: '#FDF8F2',
                padding: '11px 22px', borderRadius: 8,
                fontFamily: 'DM Sans', fontWeight: 600, fontSize: '0.78rem', letterSpacing: '0.05em',
                textDecoration: 'none',
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = P.deep_green }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = P.coffee }}
              >VIEW MY WORK →</a>
              <a href="#contact" className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: P.cream, color: P.coffee,
                padding: '11px 22px', borderRadius: 8,
                fontFamily: 'DM Sans', fontWeight: 600, fontSize: '0.78rem', letterSpacing: '0.05em',
                textDecoration: 'none', border: `1.5px solid rgba(75,38,21,0.25)`,
                transition: 'background 0.2s, border-color 0.2s',
              }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.background = P.almond; el.style.borderColor = 'rgba(75,38,21,0.4)' }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.background = P.cream; el.style.borderColor = 'rgba(75,38,21,0.25)' }}
              >LET'S CONNECT →</a>
            </div>
          </div>
          <div className="anim-fade-up delay-900 hidden md:flex justify-center items-center">
            <NotebookSketch tiltX={tiltX} tiltY={tiltY} />
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   PROJECT SKETCHES
──────────────────────────────────────────────────────────────────── */
function SkillSwapSketch({ hov }: { hov: boolean }) {
  return (
    <svg viewBox="0 0 160 88" width="160" height="88" fill="none"
      style={{ opacity: hov ? 1 : 0.5, transition: 'opacity 0.3s, transform 0.3s', transform: hov ? 'scale(1.04)' : 'scale(1)' }}>
      <circle cx="28" cy="44" r="15" stroke={P.dusty_pink} strokeWidth="1.4"/>
      <circle cx="132" cy="44" r="15" stroke={P.mojave} strokeWidth="1.4"/>
      <circle cx="80" cy="22" r="11" stroke={P.deep_green} strokeWidth="1.4"/>
      <path d="M43 44 L68 44" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <path d="M92 44 L117 44" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <path d="M43 40 L72 26" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <path d="M88 26 L117 40" stroke={P.almond} strokeWidth="1.1" strokeDasharray="4 3"/>
      <text x="21" y="48" fontFamily="Caveat" fontSize="8.5" fill={P.dusty_pink}>learn</text>
      <text x="118" y="48" fontFamily="Caveat" fontSize="8.5" fill={P.mojave}>teach</text>
      <text x="68" y="26" fontFamily="Caveat" fontSize="8.5" fill={P.deep_green}>you</text>
      <path d="M70 52 Q80 62 90 52" stroke={P.mountain} strokeWidth="1" strokeLinecap="round"/>
    </svg>
  )
}

function VeritySketch({ hov }: { hov: boolean }) {
  return (
    <svg viewBox="0 0 160 88" width="160" height="88" fill="none"
      style={{ opacity: hov ? 1 : 0.5, transition: 'opacity 0.3s, transform 0.3s', transform: hov ? 'scale(1.04)' : 'scale(1)' }}>
      {[20,24,29,32,37,40,44,48,52,55,59,62].map((x, i) => (
        <rect key={i} x={x} y={18} width={i % 3 === 0 ? 3 : 1.5} height={48} fill={P.deep_green} opacity={0.65}/>
      ))}
      <text x="30" y="78" fontFamily="JetBrains Mono" fontSize="6.5" fill={P.mountain} letterSpacing="2">4901234</text>
      <path d="M88 26 L132 26 L146 44 L132 62 L88 62 Z" stroke={P.sage} strokeWidth="1.4"/>
      <circle cx="94" cy="33" r="3" stroke={P.sage} strokeWidth="1.1"/>
      <text x="102" y="46" fontFamily="Caveat" fontSize="13" fill={P.deep_green}>₹449</text>
      <text x="102" y="57" fontFamily="Caveat" fontSize="8.5" fill={P.mountain}>↓ from ₹699</text>
      <path d="M68 44 L83 44" stroke={P.almond} strokeWidth="1.3" strokeDasharray="3 2"/>
      <path d="M79 41 L85 44 L79 47" fill={P.almond}/>
    </svg>
  )
}

function TaskPilotSketch({ hov }: { hov: boolean }) {
  return (
    <svg viewBox="0 0 160 88" width="160" height="88" fill="none"
      style={{ opacity: hov ? 1 : 0.5, transition: 'opacity 0.3s, transform 0.3s', transform: hov ? 'scale(1.04)' : 'scale(1)' }}>
      <rect x="8" y="33" width="30" height="22" rx="4" stroke={P.pale_butter} strokeWidth="1.4"/>
      <rect x="64" y="18" width="32" height="18" rx="4" stroke={P.blue_gray} strokeWidth="1.4"/>
      <rect x="64" y="52" width="32" height="18" rx="4" stroke={P.mojave} strokeWidth="1.4"/>
      <rect x="120" y="33" width="32" height="22" rx="4" stroke={P.sage} strokeWidth="1.4"/>
      <path d="M38 40 L59 27" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <path d="M38 48 L59 59" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <path d="M96 30 L115 42" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <path d="M96 58 L115 48" stroke={P.almond} strokeWidth="1.1" strokeDasharray="3 2"/>
      <text x="12" y="46" fontFamily="Caveat" fontSize="8" fill={P.pale_butter}>tasks</text>
      <text x="68" y="29" fontFamily="Caveat" fontSize="7.5" fill={P.blue_gray}>AI sort</text>
      <text x="68" y="64" fontFamily="Caveat" fontSize="7.5" fill={P.mojave}>priority</text>
      <text x="124" y="46" fontFamily="Caveat" fontSize="7.5" fill={P.sage}>done ✓</text>
      {hov && <circle cx="80" cy="44" r="4" fill={P.blue_gray} opacity="0.35"/>}
    </svg>
  )
}

/* ────────────────────────────────────────────────────────────────────
   PROJECTS — 3-column symmetric grid
──────────────────────────────────────────────────────────────────── */
const PROJECTS = [
  {
    num: '01', name: 'SkillSwap',
    desc: 'Peer-to-peer skill exchange platform connecting learners and experts in real time.',
    tech: ['React', 'Node.js', 'MongoDB', 'Express'],
    cardBg: 'linear-gradient(145deg, #FDF6F8 0%, #F9EDF1 100%)',
    borderColor: 'rgba(214,177,187,0.55)',
    accentColor: P.dusty_pink,
    accentText: P.berkeley,
    Sketch: SkillSwapSketch,
  },
  {
    num: '02', name: 'Verity',
    desc: 'Barcode scanning and real-time price comparison for smarter shopping decisions.',
    tech: ['Python', 'FastAPI', 'React', 'PostgreSQL'],
    cardBg: 'linear-gradient(145deg, #F2F8F4 0%, #EBF5EC 100%)',
    borderColor: 'rgba(158,189,155,0.5)',
    accentColor: P.sage,
    accentText: P.deep_green,
    Sketch: VeritySketch,
  },
  {
    num: '03', name: 'TaskPilot',
    desc: 'AI-powered task intelligence that prioritizes, schedules and learns your workflow.',
    tech: ['Python', 'NLP', 'React', 'TypeScript'],
    cardBg: 'linear-gradient(145deg, #FAFBF0 0%, #F5F7E8 80%, #F0F4F9 100%)',
    borderColor: 'rgba(156,171,200,0.45)',
    accentColor: P.blue_gray,
    accentText: P.deep_green,
    Sketch: TaskPilotSketch,
  },
]

function ProjectCard({ p }: { p: typeof PROJECTS[0] }) {
  const [hov, setHov] = useState(false)
  const Sketch = p.Sketch
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? p.cardBg : '#FFFEF9',
        border: `1.5px solid ${hov ? p.borderColor : 'rgba(135,118,102,0.12)'}`,
        borderRadius: 14,
        padding: '26px 22px',
        transform: hov ? 'translateY(-6px)' : 'none',
        boxShadow: hov ? '0 18px 50px rgba(75,38,21,0.08)' : '0 2px 8px rgba(75,38,21,0.03)',
        transition: 'all 0.32s cubic-bezier(0.22,1,0.36,1)',
        cursor: 'default',
        display: 'flex', flexDirection: 'column',
        position: 'relative', overflow: 'hidden',
      }}
    >
      {/* Accent strip */}
      <div style={{ height: 2, borderRadius: 4, marginBottom: 18, background: p.accentColor, width: hov ? '100%' : '26%', transition: 'width 0.4s ease' }} />

      {/* Star mark that rotates on hover */}
      <div style={{ position: 'absolute', top: 18, right: 18, transform: hov ? 'rotate(45deg)' : 'rotate(0deg)', transition: 'transform 0.4s ease' }}>
        <StarMark size={8} color={p.accentColor} rotate={0} />
      </div>

      <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.6rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 8 }}>{p.num} — PROJECT</div>
      <h3 style={{ fontFamily: 'DM Sans', fontWeight: 700, fontSize: '1.3rem', color: P.ink, letterSpacing: '-0.02em', marginBottom: 10 }}>{p.name}</h3>
      <p style={{ color: P.muted, fontSize: '0.84rem', lineHeight: 1.65, marginBottom: 18, flex: 1 }}>{p.desc}</p>

      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
        <Sketch hov={hov} />
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
          {p.tech.map(t => (
            <span key={t} style={{ fontSize: '0.64rem', color: p.accentText, padding: '3px 8px', background: `${p.accentColor}18`, borderRadius: 5, fontFamily: 'JetBrains Mono' }}>{t}</span>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 5 }}>
          {['GitHub','Live'].map(l => (
            <a key={l} href="#" style={{ fontSize: '0.64rem', color: P.muted, padding: '3px 8px', border: `1px solid rgba(135,118,102,0.2)`, borderRadius: 5, textDecoration: 'none', fontFamily: 'JetBrains Mono' }}>{l}</a>
          ))}
        </div>
      </div>
    </div>
  )
}

function Projects() {
  const ref = useReveal()
  return (
    <section id="projects" className="graph-paper py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="02" text="SELECTED WORK" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 44 }}>
            things I've built.
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 18 }}>
          {PROJECTS.map(p => <ProjectCard key={p.num} p={p} />)}
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   SKILLS — marquee with distinctly colored tiles
──────────────────────────────────────────────────────────────────── */
/* Colors per spec: C++ → dusty rose, Python → pale yellow, React → muted blue-gray,
   Node.js → sage, MongoDB → muted green, Tailwind → pale blue-gray,
   Git → warm brown/almond, Figma → almond */
const ROW1 = [
  { name: 'React',      cat: 'FRONTEND',  tileBg: '#EEF4FC', logoColor: P.blue_gray,   num: '01' },
  { name: 'Python',     cat: 'LANGUAGE',  tileBg: '#FDFBEA', logoColor: '#5C6E2A',     num: '02' },
  { name: 'Node.js',    cat: 'BACKEND',   tileBg: '#EDF6ED', logoColor: P.deep_green,  num: '03' },
  { name: 'C++',        cat: 'LANGUAGE',  tileBg: '#FAF0F4', logoColor: '#9C5F6E',     num: '04' },
  { name: 'MongoDB',    cat: 'DATABASE',  tileBg: '#EAF2EC', logoColor: P.deep_green,  num: '05' },
  { name: 'Git',        cat: 'TOOL',      tileBg: '#F8F2E8', logoColor: P.berkeley,    num: '06' },
  { name: 'Docker',     cat: 'TOOL',      tileBg: '#EDF3FA', logoColor: P.blue_gray,   num: '07' },
  { name: 'TypeScript', cat: 'LANGUAGE',  tileBg: '#EEF2FA', logoColor: '#5A73A8',     num: '08' },
]
const ROW2 = [
  { name: 'JavaScript', cat: 'LANGUAGE',  tileBg: '#FDFADF', logoColor: '#7A6010',     num: '09' },
  { name: 'FastAPI',    cat: 'BACKEND',   tileBg: '#EDF6F3', logoColor: P.muted_sage,  num: '10' },
  { name: 'PostgreSQL', cat: 'DATABASE',  tileBg: '#EEF3FA', logoColor: P.blue_gray,   num: '11' },
  { name: 'Figma',      cat: 'TOOL',      tileBg: '#F7F1E6', logoColor: P.mojave,      num: '12' },
  { name: 'NumPy',      cat: 'AI / DATA', tileBg: '#EEF2FA', logoColor: P.blue_gray,   num: '13' },
  { name: 'Pandas',     cat: 'AI / DATA', tileBg: '#FAF6ED', logoColor: P.berkeley,    num: '14' },
  { name: 'Tailwind',   cat: 'FRONTEND',  tileBg: '#E8F5F5', logoColor: P.muted_sage,  num: '15' },
  { name: 'Java',       cat: 'LANGUAGE',  tileBg: '#FBF0EC', logoColor: '#9C6040',     num: '16' },
]

function SkillTile({ t }: { t: typeof ROW1[0] }) {
  const [hov, setHov] = useState(false)
  return (
    <div
      className="skill-tile"
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: 144,
        background: hov ? t.tileBg : '#FFFEF9',
        border: `1.5px solid rgba(135,118,102,${hov ? '0.2' : '0.1'})`,
        borderRadius: 12,
        padding: '18px 14px 14px',
        margin: '0 8px',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9,
        boxShadow: hov ? '0 14px 36px rgba(75,38,21,0.09)' : '0 1px 5px rgba(75,38,21,0.03)',
        position: 'relative', overflow: 'hidden',
      }}
    >
      {/* Number top-left */}
      <span style={{
        position: 'absolute', top: 8, left: 10,
        fontFamily: 'JetBrains Mono', fontSize: '0.5rem', color: `${t.logoColor}60`, letterSpacing: '0.05em',
      }}>{t.num}</span>

      {/* Dot accent bottom-right */}
      <div style={{
        position: 'absolute', bottom: -12, right: -12,
        width: 42, height: 42, borderRadius: '50%',
        border: `1.5px solid ${t.logoColor}`,
        opacity: hov ? 0.35 : 0.1,
        transform: hov ? 'scale(1.3)' : 'scale(1)',
        transition: 'opacity 0.3s, transform 0.3s',
      }} />

      <div style={{ transform: hov ? 'scale(1.12)' : 'scale(1)', transition: 'transform 0.3s ease' }}>
        <TechLogo name={t.name} color={t.logoColor} />
      </div>

      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'DM Sans', fontWeight: 700, fontSize: '0.82rem', color: P.ink }}>{t.name}</div>
        <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.5rem', color: P.muted, letterSpacing: '0.1em', marginTop: 3 }}>{t.cat}</div>
      </div>
    </div>
  )
}

function Skills() {
  const ref = useReveal()
  return (
    <section id="skills" className="py-24 overflow-hidden" style={{ background: '#EDE8DD', backgroundImage: 'linear-gradient(rgba(135,118,102,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(135,118,102,0.08) 1px, transparent 1px)', backgroundSize: '28px 28px' }}>
      <div className="max-w-6xl mx-auto px-6">
        <div ref={ref} className="reveal">
          <Label idx="03" text="TOOLBOX" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 44 }}>
            things I build with.
          </h2>
        </div>
      </div>

      {/* Row 1 — forward */}
      <div style={{ overflow: 'hidden', marginBottom: 14, padding: '6px 0' }}>
        <div className="marquee-fwd" style={{ display: 'flex', alignItems: 'stretch' }}>
          {[...ROW1, ...ROW1].map((t, i) => <SkillTile key={i} t={t} />)}
        </div>
      </div>

      {/* Row 2 — reverse */}
      <div style={{ overflow: 'hidden', padding: '6px 0' }}>
        <div className="marquee-rev" style={{ display: 'flex', alignItems: 'stretch' }}>
          {[...ROW2, ...ROW2].map((t, i) => <SkillTile key={i} t={t} />)}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 mt-10 flex items-center gap-3">
        <span style={{ fontFamily: 'Caveat', fontSize: '0.95rem', color: P.mountain }}>// still learning, always curious</span>
        <svg viewBox="0 0 30 10" width="30" height="10" fill="none">
          <path d="M2 5 Q12 2 22 5 Q26 6 28 5" stroke={P.muted_sage} strokeWidth="1.2" strokeLinecap="round"/>
          <path d="M24 2 L28 5 L24 8" stroke={P.muted_sage} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   ABOUT
──────────────────────────────────────────────────────────────────── */
const INFO_CARDS = [
  { label: 'EDUCATION', items: ['B.Tech Computer Science'], bg: '#FAF5EE', rotate: '-0.4deg' },
  { label: 'FOCUS',     items: ['Software Engineering','AI','Full Stack'], bg: '#EEF7EE', rotate: '0.5deg' },
  { label: 'INTERESTS', items: ['Building things','Breaking things','Fixing them'], bg: '#FAF8EF', rotate: '-0.3deg' },
  { label: 'CURRENTLY', items: ['Sharpening DSA','Shipping projects','Exploring AI'], bg: '#EEF4FA', rotate: '0.4deg' },
]

function About() {
  const ref = useReveal()
  return (
    <section id="about" className="graph-paper py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal"><Label idx="04" text="ABOUT" /></div>
        <div className="grid md:grid-cols-2 gap-16 items-start mt-8">
          <div>
            <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(1.7rem,4vw,2.6rem)', color: P.ink, lineHeight: 1.3, letterSpacing: '-0.02em', marginBottom: 20 }}>
              I like understanding<br />how things work —<br />and then building them.
            </h2>
            <p style={{ color: P.muted, lineHeight: 1.8, fontSize: '0.92rem', maxWidth: 400 }}>
              I'm Aditi, a CS student with a bias for building. Whether it's wiring a full-stack
              app, poking at AI systems, or untangling a tricky algorithm — I go toward problems
              that reward curiosity. I believe software should be both{' '}
              <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', color: P.ink }}>useful</span>{' '}
              and{' '}
              <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', color: P.ink }}>beautiful</span>.
            </p>
            {/* Annotation block */}
            <div style={{ marginTop: 22, padding: '12px 16px', border: `1px solid rgba(172,189,183,0.45)`, borderRadius: 8, background: '#EEF6EE', position: 'relative' }}>
              <div style={{ position: 'absolute', top: -6, left: 14, width: 42, height: 10, background: 'rgba(236,233,190,0.72)', borderRadius: 2, transform: 'rotate(-2deg)' }} />
              <div style={{ fontFamily: 'Caveat', fontSize: '0.95rem', color: P.deep_green }}>// B.Tech CS · Year 2 · India</div>
              <div style={{ fontFamily: 'Caveat', fontSize: '0.85rem', color: P.mountain, marginTop: 3 }}>open to internships + interesting problems</div>
            </div>
            <div style={{ marginTop: 24 }}>
              <svg viewBox="0 0 200 16" width="200" height="16" fill="none">
                <path d="M4 11 Q40 7 80 10 Q120 13 160 8 Q180 6 196 10" stroke={P.almond} strokeWidth="1.4" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {INFO_CARDS.map((card, i) => (
              <div key={card.label} style={{
                background: card.bg,
                border: `1.5px solid rgba(135,118,102,0.12)`,
                borderRadius: 11, padding: '16px 14px',
                transform: `rotate(${card.rotate})`,
                position: 'relative',
              }}>
                <div style={{ position: 'absolute', top: 8, right: 10 }}>
                  <StarMark size={6} color={P.almond} rotate={i * 22} />
                </div>
                <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.58rem', color: P.muted, letterSpacing: '0.1em', marginBottom: 10 }}>{card.label}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                  {card.items.map(item => (
                    <div key={item} style={{ fontSize: '0.8rem', color: P.ink, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ width: 3, height: 3, borderRadius: '50%', background: P.mojave, flexShrink: 0 }} />
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   JOURNEY
──────────────────────────────────────────────────────────────────── */
const TIMELINE = [
  { year: '2024', tag: 'LEARNING', desc: 'Foundations: data structures, algorithms, first real projects. A lot of things breaking.', color: P.mojave },
  { year: '2025', tag: 'BUILDING', desc: 'Full-stack apps, AI experiments, open source contributions, learning to ship.', color: P.muted_sage },
  { year: '2026', tag: 'SHIPPING', desc: 'Real products. SkillSwap, Verity, TaskPilot — and more on the way.', color: P.sage },
  { year: 'NEXT', tag: '?',        desc: 'Internships, collaborations, and whatever interesting problem finds me next.', color: P.dusty_pink },
]

function Journey() {
  const ref = useReveal()
  const lineRef = useJourneyLine()
  return (
    <section id="journey" className="py-24 px-6" style={{ background: '#EDE8DD', backgroundImage: 'linear-gradient(rgba(135,118,102,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(135,118,102,0.08) 1px, transparent 1px)', backgroundSize: '28px 28px' }}>
      <div className="max-w-6xl mx-auto">
        <div ref={ref} className="reveal">
          <Label idx="05" text="JOURNEY" />
          <h2 style={{ fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, fontSize: 'clamp(2rem,5vw,3.4rem)', color: P.ink, letterSpacing: '-0.02em', marginBottom: 52 }}>
            where I've been.
          </h2>
        </div>
        <div style={{ position: 'relative', paddingLeft: 34 }}>
          <svg style={{ position: 'absolute', left: 8, top: 8, width: 6, height: 'calc(100% - 16px)', overflow: 'visible' }}
            viewBox="0 0 6 600" preserveAspectRatio="none">
            <path ref={lineRef} d="M3 0 Q4 80 2 160 Q4 240 3 320 Q2 400 4 480 Q3 540 3 600"
              stroke={P.berkeley} strokeWidth="1.5" fill="none" className="journey-line" strokeLinecap="round"/>
          </svg>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 44 }}>
            {TIMELINE.map((t, i) => (
              <div key={t.year} style={{ position: 'relative', display: 'flex', alignItems: 'flex-start', gap: 22 }}>
                <div style={{
                  position: 'absolute', left: -34, top: 6,
                  width: 12, height: 12, borderRadius: '50%',
                  background: t.color, border: `2px solid #EDE8DD`,
                  boxShadow: `0 0 10px ${t.color}88`, zIndex: 2,
                }} />
                <div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 7 }}>
                    <span style={{ fontFamily: 'JetBrains Mono', fontWeight: 500, fontSize: '1.05rem', color: P.ink }}>{t.year}</span>
                    <span style={{ fontFamily: 'DM Sans', fontWeight: 700, fontSize: '0.7rem', letterSpacing: '0.09em', color: t.color, padding: '2px 9px', background: `${t.color}22`, borderRadius: 20 }}>{t.tag}</span>
                    {t.year === 'NEXT' && <span style={{ fontFamily: 'Caveat', fontSize: '0.9rem', color: P.mountain }}>↩ TBD</span>}
                    {i === 2 && <span style={{ fontFamily: 'Caveat', fontSize: '0.82rem', color: P.muted }}>this one was fun</span>}
                  </div>
                  <p style={{ color: P.muted, fontSize: '0.88rem', lineHeight: 1.65, maxWidth: 460 }}>{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   CONTACT
──────────────────────────────────────────────────────────────────── */
function Contact() {
  const ref = useReveal()
  return (
    <section id="contact" className="graph-paper py-28 px-6 relative overflow-hidden">
      <div style={{ position: 'absolute', top: '40%', left: '50%', transform: 'translate(-50%,-50%)', width: 560, height: 400, borderRadius: '50%', background: `radial-gradient(ellipse, rgba(172,189,183,0.1) 0%, rgba(232,209,220,0.06) 40%, transparent 68%)`, pointerEvents: 'none' }} />
      <div className="max-w-5xl mx-auto relative z-10">
        <div ref={ref} className="reveal text-center">
          <Label idx="06" text="CONTACT" />
          <h2 style={{ fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: 'clamp(2.6rem,7vw,5.5rem)', color: P.ink, letterSpacing: '-0.04em', lineHeight: 0.9, marginTop: 14, marginBottom: 20 }}>
            LET'S BUILD<br />
            <span style={{
              fontFamily: 'Fraunces, serif', fontStyle: 'italic', fontWeight: 300, letterSpacing: '-0.02em',
              background: `linear-gradient(115deg, ${P.dusty_pink} 0%, ${P.mojave} 50%, ${P.deep_green} 100%)`,
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            }}>SOMETHING</span><br />
            INTERESTING.
          </h2>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 28 }}>
            <span style={{ fontFamily: 'Caveat', fontSize: '1.05rem', color: P.muted_sage }}>open to internships + collaborations</span>
            <svg viewBox="0 0 20 10" width="20" height="10" fill="none">
              <path d="M2 5 Q10 2 17 5" stroke={P.muted_sage} strokeWidth="1.1" strokeLinecap="round"/>
              <path d="M13 2 L17 5 L13 8" stroke={P.muted_sage} strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 52 }}>
            {[{ label: 'GitHub', href: 'https://github.com' }, { label: 'LinkedIn', href: 'https://linkedin.com' }, { label: 'Email', href: 'mailto:aditi@example.com' }].map(({ label, href }) => (
              <a key={label} href={href} className="btn-mag" style={{
                display: 'inline-flex', alignItems: 'center', gap: 7,
                padding: '10px 22px', borderRadius: 9,
                border: `1.5px solid rgba(135,118,102,0.2)`,
                color: P.ink, fontSize: '0.82rem', fontWeight: 500,
                letterSpacing: '0.04em', textDecoration: 'none',
                background: '#FFFEF9', transition: 'all 0.22s ease',
              }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = P.deep_green; el.style.background = '#EEF6EE' }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = 'rgba(135,118,102,0.2)'; el.style.background = '#FFFEF9' }}
              >{label} →</a>
            ))}
          </div>
          <div style={{ display: 'inline-block', background: P.ink, color: P.mojave, borderRadius: 9, padding: '11px 18px', fontFamily: 'JetBrains Mono', fontSize: '0.7rem' }}>
            {'$ echo "let\'s build something"'}
            <span className="cursor-blink" style={{ color: P.sage, marginLeft: 4 }}>▌</span>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────────────────────────────────────────────
   FOOTER
──────────────────────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="graph-paper" style={{ borderTop: `1px solid rgba(135,118,102,0.14)`, padding: '24px' }}>
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <StarMark size={8} color={P.mojave} rotate={0} spin />
          <span style={{ fontFamily: 'Fraunces', fontStyle: 'italic', fontWeight: 300, fontSize: '1.05rem', color: P.coffee }}>aditi.</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: 'Caveat', fontSize: '0.92rem', color: P.muted }}>made with curiosity.</div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: '0.57rem', color: P.muted, marginTop: 2, letterSpacing: '0.05em' }}>C++ · React · Python · AI</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: P.sage, display: 'inline-block', boxShadow: `0 0 5px ${P.sage}` }} />
          <span style={{ fontFamily: 'JetBrains Mono', fontSize: '0.57rem', color: P.muted, letterSpacing: '0.07em' }}>ONLINE</span>
        </div>
      </div>
    </footer>
  )
}

/* ────────────────────────────────────────────────────────────────────
   ROOT
──────────────────────────────────────────────────────────────────── */
export default function App() {
  return (
    <div style={{ fontFamily: 'DM Sans, sans-serif', background: P.paper }}>
      <CustomCursor />
      <Navbar />
      <Hero />
      <Projects />
      <Skills />
      <About />
      <Journey />
      <Contact />
      <Footer />
    </div>
  )
}
